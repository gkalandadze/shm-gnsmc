
/* file KSDEFS.H
 *      ========
 *
 * version 1, 22-MAY-91
 *
 * basic definitions (shouldn't be used any more)
 * K. Stammler, 22-MAY-91
 */


#ifndef __KSDEFS
#define __KSDEFS

#define If if
#define Then {
#define Else }else{
#define Elsif }else if
#define Endif }

#endif /* __KSDEFS */
