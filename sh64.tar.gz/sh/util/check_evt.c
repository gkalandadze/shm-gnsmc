
/* file check_evt.c
 *      ===========
 *
 * version 10, 16-Jan-2007
 *
 * Checks consistency of created output file of SHM
 * K. Stammler, 21-Jul-94
 */


/*
 *
 *  SeismicHandler, seismic analysis software
 *  Copyright (C) 1996,  Klaus Stammler, Federal Institute for Geosciences
 *                                       and Natural Resources (BGR), Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include BASECNST
#include BC_SYSBASE
#include "eventdsc.h"
#include "tcusrdef.h"
#include "earthloc.h"


#define MAX_PKP_SLOWNESS 4.5
#define MIN_P_SLOWNESS 4.3

#define EVTYPE_UNDEF 0
#define EVTYPE_LOCAL 1
#define EVTYPE_P     2
#define EVTYPE_PKP   3

/* next error number currently 031 */



/* global variables */
static float   efv_reflat=49.0;           /* reference latitude */
static float   efv_reflon=11.0;           /* reference longitude */
static char    efv_infile[BC_FILELTH+1];  /* name of input file */
static char    efv_uncorrphase[EvPHASELTH+1]; /* name of phase on uncorr beam */
static BOOLEAN efv_first_arrival=FALSE;   /* first arrival phase selected */
static BOOLEAN efv_only_grf=TRUE;         /* only GRF stations used */
static BOOLEAN efv_gra1_picked=FALSE;     /* pick on GRA1 found */
static BOOLEAN efv_uncorr_loc=FALSE;      /* uncorrected beam for location */
static BOOLEAN efv_telex_phase=FALSE;     /* telex phase found */
static BOOLEAN efv_mb_found=FALSE;        /* mb determination done */
static BOOLEAN efv_ms_found=FALSE;        /* ms determination done */
static BOOLEAN efv_mbb_found=FALSE;       /* mbb determination done */
static BOOLEAN efv_depth_phase_found=FALSE;/* depth phase found? */
static int     efv_subtype=EVTYPE_UNDEF;  /* event type */
static EvEventTypeT efv_evtype=EvcEventTypeUndefined; /* event type */
static float   efv_depth=(-100.0);        /* depth of event */
static float   efv_magn=0.0;              /* max. magnitude found */
static int     efv_pkp_count=0;           /* number of PKP phases */
static BOOLEAN efv_illegal_origin=FALSE;  /* illegal origin time */
static BOOLEAN efv_foundPg=FALSE;         /* Pg phase found */
static BOOLEAN efv_foundPnSn=FALSE;       /* Pn/Sn found */
static BOOLEAN efv_foundTele=FALSE;       /* teleseismic phase found */
static float   efv_latitude=0.0;          /* epicentre latitude */
static float   efv_longitude=0.0;         /* epicentre longitude */
static char    efv_analyst[EvANALYSTLTH+1]=""; /* analysts initials */
static BOOLEAN efv_showinitials=FALSE;    /* show initials */


/* prototypes of local routines */
void EfPutCheck( FILE *out, EvEventT *event, EvStatusT *status );
static BOOLEAN EfPhaseIsFirstArrival( char name[] );
static void EfFinalCheck( FILE *out );
static BOOLEAN EfIsLocalPhase( char phase[] );



int main( int argc, char *argv[] )
{
	/* local variables */
	char      infile[BC_FILELTH+1];    /* input file */
	char      outfile[BC_FILELTH+1];   /* output file */
	EvStatusT status;                  /* return status */
	int       i;                       /* counter */
    char      tmpstr[cBcLongStrLth+1]; /* scratch string */

	/* executable code */

	if  (argc < 2)  {
		fprintf( stderr, "Usage: %s <input> [<output>] [<showinitials>]\n",
			argv[0] );
		return 1;
	} /*endif*/

	strcpy( infile, argv[1] );
	if  (argc > 2)  {
		strcpy( outfile, argv[2] );
		if  (*outfile == '\0')
			strcpy( outfile, "TT" );
	} else {
		strcpy( outfile, "TT" );
	} /*endif*/
	efv_showinitials = FALSE;
	if  (argc > 3)
		efv_showinitials = (strcmp(argv[3],"showinitials") == 0);

#ifdef XXX
	/* efv_infile is used for messages, directory will be removed */
	i = strlen( infile ) - 1;
	while  (infile[i] != '/' && i > 0)
		i--;
	strcpy( efv_infile, infile+i );
#endif
    strcpy( efv_infile, infile );

	status = EveNOERROR;
	EvReformatEventfile( infile, outfile, EvGetEvent,
		EfPutCheck, &status );

    /* now call the Python script for additional checks */
    if  (strcmp(outfile,"TT") == 0)  {
        sprintf( tmpstr, "%s/CheckEvt.py %s", (char *)getenv("SH_UTIL"),
            efv_infile );
        system( tmpstr );
    } else {
        sprintf( tmpstr, "%s/CheckEvt.py %s %s", (char *)getenv("SH_UTIL"),
            efv_infile, outfile );
        system( tmpstr );
    } /*endif*/

	return 0;

} /* end of main */



/*---------------------------------------------------------------------------*/



void EfPutCheck( FILE *out, EvEventT *event, EvStatusT *status )

/* Prints error messages of event to file 'out'.
 *
 * parameters of routine
 * FILE       *out;          input; output file
 * EvEventT   *event;        input; event information
 * EvStatusT  *status;       output; return status
 */
{
	/* local variables */
	static BOOLEAN locqual_checked=FALSE; /* location quality checked ? */
	BOOLEAN  amplitude_measured;      /* amplitude measured */
	BOOLEAN  is_l_phase;              /* phase is L (or (L)) */
	BOOLEAN  is_pkp_phase;            /* phase is PKP */
	BOOLEAN  is_p_phase;              /* phase is P or (P) */
	BOOLEAN  loc_given;               /* location given in this record */
	NTIME    ntime;                   /* numeric origin time */

	/* executable code */

	/* final check if event is NULL */
	if  (event == NULL)  {
		EfFinalCheck( out );
		locqual_checked = FALSE;
		return;
	} /*endif*/

	/* fprintf( out, "--> check phase %s\n", event->phase ); */

	/* is a location given here ? */
	loc_given = (event->latitude > 0.0 && event->longitude > 0.0);
	if  (loc_given)  {
		efv_latitude = event->latitude;
		efv_longitude = event->longitude;
	} /*endif*/

	/* is this an L phase ? */
	is_l_phase = (strcmp(event->phase,"L") == 0
		|| strcmp(event->phase,"(L)") == 0);

	/* is this a P phase ? */
	is_p_phase = (strcmp(event->phase,"P") == 0
		|| strcmp(event->phase,"(P)") == 0);

	/* is this a PKP phase ? */
	is_pkp_phase = (strstr(event->phase,"PKP") != NULL);
	if  (is_pkp_phase)
		efv_foundTele = TRUE;

	/* is it a depth phase ? */
	if (event->phase[0] == 'p' || event->phase[0] == 's')
		efv_depth_phase_found = TRUE;
	/* or from foreign source */
	if (event->source[0] != '\0' && (strcmp(event->source,"BGR") != 0)
		&& (strcmp(event->source,"SZGRF") != 0))
		efv_depth_phase_found = TRUE;  /* assume that the other source has one*/

    /* is this a leftover from an amplitude measurement? */
    if  (strncmp(event->phase,"w-",2) == 0)
		fprintf( out, "F012 %s: illegal phase %s found on %s\n",
			efv_infile, event->phase, event->station );
        

	/* a depth phase can found only in teleseismic events */
	if  (event->phase[0] == 'p' || event->phase[0] == 's')
		efv_foundTele = TRUE;

	/* check for local and regional phases */
	if  (strcmp(event->phase,"Pg") == 0)
		efv_foundPg = TRUE;
	if  (strcmp(event->phase,"Pn") == 0)
		efv_foundPnSn = TRUE;
	if  (strcmp(event->phase,"Sn") == 0)
		efv_foundPnSn = TRUE;

	if  (event->event_type != EvcEventTypeUndefined)
		efv_evtype = event->event_type;

	/* setup global variables used in final check */
	/* ------------------------------------------ */

	/* is it a GRF station ? */
	if  (strncmp(event->station,"GR",2) != 0
		|| event->station[2] < 'A' || event->station[2] > 'C')
		efv_only_grf = FALSE;
	if  (strcmp(event->station,"GRA1") == 0)
		efv_gra1_picked = TRUE;

	/* is a first arrival phase there ? */
	if  (EfPhaseIsFirstArrival(event->phase))
		efv_first_arrival = TRUE;

	/* is there a location done with uncorrected beam ? */
	if  ((loc_given && event->b_slowness != EvEMPTY_SLOWNESS &&
		event->l_slowness == EvEMPTY_SLOWNESS
		&& event->loc_quality == EvcLocQualReliable
		&& strcmp(event->source,"SZGRF") == 0)
		|| (event->loc_method == EvcLocMethUncorrBeam))  {
		efv_uncorr_loc = TRUE;
		strcpy( efv_uncorrphase, event->phase );
	} /*endif*/

	/* is there an origin time from 1970? */
	if  (loc_given)  {
		tc_t2n( event->origin_time, &ntime, status );
		if  (SySevere(status))  {
			efv_illegal_origin = TRUE;
		} else if  (ntime.year == 1970)  {
			efv_illegal_origin = TRUE;
		} /*endif*/
	} /*endif*/

	/* look for telex phase */
	if  (strchr(event->phase_flags,EvFLAG_TELEX) != NULL)
		efv_telex_phase = TRUE;

	/* look for depth */
	if  (efv_depth < -99.0 && event->depth_type != EvcDepthUndefined)
		efv_depth = event->depth;

	/* find plain mistakes */
	/* ------------------- */

	/* special for L phases */
	if  (is_l_phase)  {
		/* is there an impulsive L phase ? */
		if  (event->onset_type == EvcOnsetImpulsive)
			fprintf( out, "F001 %s: phase L with impulsive onset\n", efv_infile );
		/* is a legal filter used ? */
		if  (strcmp(event->filter,"G_WWSSN_SP") == 0
			|| strcmp(event->filter,"STANDARD_BP") == 0
			|| event->filter[0] == '\0')
			fprintf( out, "F002 %s: L phase reading with illegal filter %s\n",
				efv_infile, event->filter );
		/* is there slowness and azimuth ? if yes that's real nonsense */
		if  (event->b_slowness != EvEMPTY_SLOWNESS
			|| event->b_azimuth != EvEMPTY_AZIMUTH
			|| event->l_slowness != EvEMPTY_SLOWNESS
			|| event->l_azimuth != EvEMPTY_AZIMUTH)
			fprintf( out, "F003 %s: slowness and/or azimuth for phase %s\n",
				efv_infile, event->phase );
		/* is amplitude & period determined ? */
		if  (event->amplitude == EvEMPTY_AMPLITUDE
			|| event->period == EvEMPTY_PERIOD)
			fprintf( out, "F004 %s: no amplitude / period for phase %s\n",
				efv_infile, event->phase );
	} /*endif*/

	if  (is_pkp_phase)  {
		/* check slowness range */
		if  (event->b_slowness != EvEMPTY_SLOWNESS
			&& event->b_slowness > MAX_PKP_SLOWNESS)
			fprintf( out, "F005 %s: illegal beam slowness %3.1f for phase %s\n",
				efv_infile, event->b_slowness, event->phase );
		if  (event->l_slowness != EvEMPTY_SLOWNESS
			&& event->l_slowness > MAX_PKP_SLOWNESS)
			fprintf( out, "F006 %s: illegal corr. slowness %3.1f for phase %s\n",
				efv_infile, event->l_slowness, event->phase );
		efv_subtype = EVTYPE_PKP;
		efv_pkp_count++;
	} /*endif*/

	if  (is_p_phase)  {
		/* check slowness range */
		if  (event->b_slowness != EvEMPTY_SLOWNESS
			&& event->b_slowness < MIN_P_SLOWNESS)
			if  (event->l_slowness == EvEMPTY_SLOWNESS)
				fprintf( out, "F007 %s: illegal beam slowness %3.1f for phase %s\n",
					efv_infile, event->b_slowness, event->phase );
		if  (event->l_slowness != EvEMPTY_SLOWNESS
			&& event->l_slowness < MIN_P_SLOWNESS)
			fprintf( out, "F008 %s: illegal corr. slowness %3.1f for phase %s\n",
				efv_infile, event->l_slowness, event->phase );
		efv_subtype = EVTYPE_P;
	} /*endif*/

	if  (EfIsLocalPhase(event->phase))  efv_subtype = EVTYPE_LOCAL;

	/* amplitude measurement must be complete */
	amplitude_measured = (event->period != EvEMPTY_PERIOD
		|| event->amplitude != EvEMPTY_AMPLITUDE
		|| event->amplitude_time != EvEMPTY_AMPLITUDE_TIME
		|| event->amplitude_vel != EvEMPTY_AMPLITUDE);
	if  (amplitude_measured)
		if  (event->period == EvEMPTY_PERIOD
			|| event->amplitude == EvEMPTY_AMPLITUDE
			|| (event->amplitude_time == EvEMPTY_AMPLITUDE_TIME && !is_l_phase)
			|| event->amplitude_vel == EvEMPTY_AMPLITUDE
			|| event->ap_source == EvcApSourceUndefined)
			fprintf( out,
				"F009 %s: incomplete amplitude determination at phase %s, station %s\n",
				efv_infile, event->phase, event->station );

	/* check for magnitudes determined */
	if  (event->mag[EvcMagMb] != EvEMPTY_MAGNITUDE)  {
		efv_mb_found = TRUE;
		if  (event->mag[EvcMagMb] > efv_magn)  efv_magn = event->mag[EvcMagMb];
	} /*endif*/
	if  (event->mag[EvcMagMs] != EvEMPTY_MAGNITUDE)  {
		efv_ms_found = TRUE;
		if  (event->mag[EvcMagMs] > efv_magn)  efv_magn = event->mag[EvcMagMs];
	} /*endif*/
	if  (event->mag[EvcMagMbb] != EvEMPTY_MAGNITUDE) efv_mbb_found = TRUE;

	/* magnitudes mb,MS are valid only with amplitude */
	if  (event->mag[EvcMagMs] != EvEMPTY_MAGNITUDE
		|| event->mag[EvcMagMb] != EvEMPTY_MAGNITUDE)
		if  (!amplitude_measured)
			fprintf( out, "F010 %s: magnitude without amplitude on phase %s\n",
				efv_infile, event->phase );

	/* a reliable location with PKP is not possible */
	if  (event->loc_quality == EvcLocQualReliable && is_pkp_phase
		&& strcmp(event->source,"SZGRF") == 0 && loc_given)
		fprintf( out, "F011 %s: reliable location with phase %s not possible\n",
			efv_infile, event->phase );

	/* event type tele and local phases Pn, Pg, Sn, Sg */
	if  (event->event_type == EvcEventTypeTeleQuake
		&& EfIsLocalPhase(event->phase))
		fprintf( out, "F012 %s: incompatible event type TELE with phase %s\n",
			efv_infile, event->phase );

	/* is there a location quality specified in the first phase ? */
	if  (loc_given && !locqual_checked && event->phase[0] != '\0')  {
		if  (event->loc_quality == EvcLocQualUndefined)
			fprintf( out, "F013 %s: no location quality specified\n", efv_infile );
		locqual_checked = TRUE;
	} /*endif*/

	if  (event->analyst[0] != '\0')
		strcpy( efv_analyst, event->analyst );

} /* end of EfPutCheck */



/*---------------------------------------------------------------------------*/



static BOOLEAN EfPhaseIsFirstArrival( char name[] )

/* Checks whether phase is first arrival
 *
 * parameters of routine
 * char       name[];        input; name of phase
 *                           returns TRUE if phase is possible first arrival
 */
{
	/* executable code */

	if  (strcmp(name,"P") == 0)  return TRUE;
	if  (strcmp(name,"(P)") == 0)  return TRUE;
	if  (strncmp(name,"PKP",3) == 0)  return TRUE;
	if  (strncmp(name,"(PKP",4) == 0)  return TRUE;
	if  (strncmp(name,"Pn",2) == 0)  return TRUE;
	if  (strncmp(name,"Pg",2) == 0)  return TRUE;
	if  (strcmp(name,"(Pn)") == 0)  return TRUE;
	if  (strcmp(name,"(Pg)") == 0)  return TRUE;
	if  (strcmp(name,"Pdiff") == 0)  return TRUE;
	if  (strcmp(name,"(Pdiff)") == 0)  return TRUE;
	if  (strcmp(name,"Pdif") == 0)  return TRUE;
	if  (strcmp(name,"(Pdif)") == 0)  return TRUE;

	return FALSE;

} /* end of EfPhaseIsFirstArrival */



/*---------------------------------------------------------------------------*/



static void EfFinalCheck( FILE *out )

/* Prints result of final check to output file 'out'
 *
 * parameters of routine
 * FILE       *out;         input; pointer to output file
 */
{
	/* local variables */
	char     expl[cBcLongStrLth+1];   /* explanation string */

	/* executable code */

	/* fprintf( out, "--> final check\n" ); */
	if  (efv_showinitials)
		sprintf( expl, "%s (%s)", efv_infile, efv_analyst );
	else
		strcpy( expl, efv_infile );

	/* a first arrival must be specified */
	if  (!efv_first_arrival)
		fprintf( out, "F014 %s: no first arrival phase selected\n", expl );

	/* beam with uncorrected slowness at GRF is at least suspicious */
	if  (efv_only_grf && efv_uncorr_loc)
		fprintf( out, "F015 %s: GRF location with uncorrected beam at phase %s\n",
			expl, efv_uncorrphase );

	/* only GRF picked but no GRA1? */
	if  (efv_only_grf && !efv_gra1_picked)
		fprintf( out, "F035 %s: only GRF picks but none at GRA1\n", expl );

	/* no telex phase */
	/* disabled 12-Nov-2008 K.S.
	if  (!efv_telex_phase)
		fprintf( out, "F016 %s: no telex phase found\n", expl );
	*/

	/* mb determined? */
	if  (efv_subtype == EVTYPE_P && !efv_mb_found)
		fprintf( out, "F017 %s: no Magnitude mb determined for P phase\n", expl );

	/* Ms determined? */
	if  (efv_subtype >= EVTYPE_P && efv_depth <= 50.0 && efv_magn > 5.6 &&
		!efv_ms_found)
		fprintf( out, "F018 %s: no Magnitude Ms determined for magn %3.1f event\n",
			expl, efv_magn );
	if  (efv_subtype == EVTYPE_PKP && efv_depth <= 50.0 && efv_pkp_count > 3 &&
		!efv_ms_found)
		fprintf( out, "F019 %s: no Magnitude Ms determined for PKP event\n",
			expl );
	if  (efv_ms_found && efv_depth > 50.0)
		fprintf( out, "F020 %s: Magnitude Ms determined for depth %5.1f event\n",
			expl, efv_depth );

	/* Mbb determined? */
	if  (efv_mb_found && efv_magn > 6.2 && !efv_mbb_found)
		fprintf( out, "F021 %s: no Broadband Magnitude determined for magn %3.1f event\n",
			expl, efv_magn );

	/* depth ok? */
	if  (efv_evtype == EvcEventTypeMining && Abs(efv_depth-1.0) > 0.1)
		fprintf( out, "F022 %s: depth %5.1f given for mining event\n",
			expl, efv_depth );
	if  (efv_evtype == EvcEventTypeBlast && Abs(efv_depth) > 0.1)
		fprintf( out, "F023 %s: depth %5.1f given for blast\n",
			expl, efv_depth );
	if  (efv_evtype == EvcEventTypeTeleQuake && (efv_depth < 10.0))
		fprintf( out, "F026 %s: depth %5.1f for teleseismic event\n",
			expl, efv_depth );
	if  (efv_evtype == EvcEventTypeTeleQuake && !efv_depth_phase_found
		&& ((efv_depth-33.0) > 0.01))
		fprintf( out, "F037 %s: depth %5.1f for teleseismic event without depth phases\n",
			expl, efv_depth );
	if  ((efv_evtype == EvcEventTypeLocalQuake
		|| efv_evtype == EvcEventTypeRegioQuake) && (efv_depth < 2.0))
		fprintf( out, "F027 %s: depth %5.1f for local/regional event\n",
			expl, efv_depth );
	if  (efv_evtype == EvcEventTypeLocalQuake && efv_depth > 50.0)
		fprintf( out, "F036 %s: depth %5.1f given for local event\n",
			expl, efv_depth );
	if  (efv_evtype == EvcEventTypeUndefined)
		fprintf( out, "F024 %s: no event type specified\n", expl );
	if  (efv_depth < -99.0)
		fprintf( out, "F025 %s: no depth specified\n", expl );

	/* proper event type? */
	if  (efv_foundPg && efv_evtype == EvcEventTypeTeleQuake)
		fprintf( out, "F028 %s: improper teleseismic event type: found Pg\n",
			expl );
	if  (efv_foundPnSn && efv_evtype == EvcEventTypeTeleQuake)
		fprintf( out, "F029 %s: improper teleseismic event type: found Pn/Sn\n",
			expl );
	if  (efv_foundTele && efv_evtype == EvcEventTypeLocalQuake)
		fprintf( out, "F030 %s: improper local event type: found tele phase\n",
			expl );
	if  (efv_foundTele && efv_evtype == EvcEventTypeRegioQuake)
		fprintf( out, "F031 %s: improper regional event type: found tele phase\n",
			expl );

	/* check distance and event type */
	if  (efv_latitude != 0.0 || efv_longitude != 0.0)  {
		double dist, azim, bazim;   /* result of distance computation */
		float fdist;    /* single precision distance */
		mb_locdiff( (double)efv_reflat, (double)efv_reflon, (double)efv_latitude,
			(double)efv_longitude, &dist, &azim, &bazim );
		fdist = dist;
		if  (dist > 15.0 && efv_evtype == EvcEventTypeLocalQuake)
			fprintf( out, "F032 %s: improper local event type (distance %f deg)\n",
				expl, dist );
		if  (dist > 30.0 && efv_evtype == EvcEventTypeRegioQuake)
			fprintf( out, "F033 %s: improper regional event type (distance %f deg)\n",
				expl, dist );
		if  (dist < 25.0 && efv_evtype == EvcEventTypeTeleQuake)
			fprintf( out, "F034 %s: improper teleseismic event type (distance %f deg)\n",
				expl, dist );
	} /*endif*/

	if  (efv_illegal_origin)
		fprintf( out, "F038 %s: check year of origin time (1970?)\n", expl );


} /* end of EfFinalCheck */



/*---------------------------------------------------------------------------*/



static BOOLEAN EfIsLocalPhase( char phase[] )

/* checks whether 'phase' is a local phase
 *
 * parameters of routine
 * char       phase[];         input; phase name
 */
{
	/* local variables */

	/* executable code */

	if  (strcmp(phase,"Pg") == 0)  return TRUE;
	if  (strcmp(phase,"Pn") == 0)  return TRUE;
	if  (strcmp(phase,"Sg") == 0)  return TRUE;
	if  (strcmp(phase,"Sn") == 0)  return TRUE;
	if  (strcmp(phase,"(Pg)") == 0)  return TRUE;
	if  (strcmp(phase,"(Pn)") == 0)  return TRUE;
	if  (strcmp(phase,"(Sg)") == 0)  return TRUE;
	if  (strcmp(phase,"(Sn)") == 0)  return TRUE;

	return FALSE;

} /* end of EfIsLocalPhase */



/*---------------------------------------------------------------------------*/

