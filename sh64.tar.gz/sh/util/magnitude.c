
/* file magnitude.c
 *      ===========
 *
 * $Revision$, $Date$
 *
 * Compute magnitude using SH routines.
 * K. Stammler, 12-jan-2012
 */

#include <string.h>
#include <stdio.h>
#include <math.h>
#include "basecnst.h"
#include "sysbase.h"

#define STRLEN 132

/*---------------------------------------------------------------------------*/



#define MAGN_ML_MIN_DIST 16
#define MAGN_ML_MAX_DIST 120
#define SIE_MAGN_DIST_OOR 1
#define SIE_VALUE_OOR 2

/*typedef int STATUS;*/



float magn_mb( float ampl, float period, float distance, STATUS *status )

/* Returns magnitude mb.  Passed amplitude and period must origin from a
 * Z component.
 *
 * parameters of routine
 * float      ampl;        input; amplitude in nm
 * float      period;      input; amplitude in sec
 * float      distance;    input; epicentral distance in deg
 * STATUS     *status;     output; return status
 *                         returns value of mb
 */
{

	/* local data array */
	static float mb_sigma[] = {
		5.9,5.9,5.9,6.0,6.0,6.1,6.2,6.3,6.3,6.5,6.4,6.5,6.6,
		6.6,6.6,6.7,6.7,6.7,6.7,6.7,6.6,6.5,6.5,6.4,6.4,6.5,6.5,6.5,6.5,
		6.7,6.8,6.9,6.9,6.8,6.7,6.7,6.7,6.7,6.8,6.8,6.8,6.8,6.8,6.8,6.8,
		6.6,7.0,6.9,7.0,7.0,7.0,7.0,7.0,7.0,6.9,6.9,6.9,6.9,6.8,6.8,6.9,
		6.9,6.9,6.8,6.7,6.8,6.9,7.0,7.0,7.0,6.9,6.9,7.1,7.0,7.0,7.1,7.1,
		7.2,7.1,7.2,7.3,7.4,7.5,7.5,7.4,7.3,7.4,7.5,7.6,7.7,7.8,7.9,7.9,
		8.0,8.1,8.2,8.2,8.4,8.6,8.7,8.8,8.9,9.0,9.0,9.0
	};

	/* local variables */
	int      idist;     /* rounded distance */
	float    tmp;       /* scratch */

	/* executable code */

	idist = Nint( distance );
	if  (idist < MAGN_ML_MIN_DIST || idist > MAGN_ML_MAX_DIST)  {
		*status = SIE_MAGN_DIST_OOR;
		return 0.0;
	} /*endif*/

	if  (ampl <= 0.0 || period <= 0.0)  {
		*status = SIE_VALUE_OOR;
		return 0.0;
	} /*endif*/

	/* rescale to microns */
	ampl /= 1000.0;

	tmp = log10( (double)(ampl/period) ) + mb_sigma[idist-MAGN_ML_MIN_DIST];

    /*
	if  (GpGetInt(cGpI_debug_level) > 1)
		printf( "SHM-dbg2: mb %3.1f, distance %5.1f, period %5.2f, ampl %f\n",
			tmp, distance, period, ampl );
    */
	return tmp;

	/* this didn't work (in dbxtool):
	return ( log10(ampl/period) + mb_sigma[idist-MAGN_ML_MIN_DIST] );
	*/

} /* end of magn_mb */



#undef MAGN_ML_MIN_DIST
#undef MAGN_ML_MAX_DIST



/*---------------------------------------------------------------------------*/



float magn_ms_plain( float ampl, float period, float distance,
	STATUS *status )

/* returns MS magnitude, using Prague formula
 *
 * parameters of routine
 * float      ampl;        input; amplitude in nm
 * float      period;      input; amplitude in sec
 * float      distance;    input; epicentral distance in deg
 * STATUS     *status;     output; return status
 *                         returns value of MS
 */
{
	/* local data array */
	float ms_min_period[] = {
		4,4,5,5,5,6,6,7,7,9,10,12,13,14,15,16,16,16,17,17,18,18
	};

	/* local variables */
	float    tmp;       /* scratch */
	int      index;     /* index in ms_min_period */
	int      idist;     /* rounded distance */
	float    minper;    /* minimum period */

	/* executable code */

	/* check distance & period */
	idist = Nint( distance );
	if  (idist < 2)  {
		*status = SIE_MAGN_DIST_OOR;
		return 0.0;
	} else if  (idist > 140)  {
		minper = 18.0;
	} else {
		index = (idist > 10) ? Nint(distance/10.0)+7 : Nint(distance)-2;
		minper = ms_min_period[index];
	} /*endif*/
	if  (period < minper)  {
		*status = SIE_VALUE_OOR;
		return 0.0;
	} /*endif*/

	/* check amplitude */
	if  (ampl <= 0.0)  {
		*status = SIE_VALUE_OOR;
		return 0.0;
	} /*endif*/

	/* rescale to microns */
	ampl /= 1000.0;

	tmp = log10((double)(ampl/period)) + 1.66*log10((double)distance) + 3.3;

    /*
	if  (GpGetInt(cGpI_debug_level) > 0)
		printf( "SHM-dbg1: MS %3.1f, distance %5.1f, period %5.2f, ampl %f\n",
			tmp, distance, period, ampl );
    */
	return tmp;

} /* end of magn_ms_plain */



/*---------------------------------------------------------------------------*/


int main( int argc, char *argv[] )
{
	/* local variables */
    char     magn[STRLEN+1];  /* magnitude name */
    float    ampl;            /* amplitude */
    float    period;          /* signal period */
    float    dist;            /* distance in deg */
    float    mb;              /* magnitude */
    int      ok;              /* distance ok? */
    int      status;          /* status variable */
    float    m;               /* magnitude result */

    /* executable code */

    if  (argc != 5)  {
        fprintf( stderr, "Usage: %s <magn> <ampl> <period> <distance>\n", argv[0] );
        return 1;
    } /*endif*/

    strcpy( magn, argv[1] );
    if  (sscanf(argv[2],"%f",&ampl) != 1)  {
        fprintf( stderr, "illegal amplitude %s\n", argv[2] );
        return 1;
    } /*endif*/
    if  (sscanf(argv[3],"%f",&period) != 1)  {
        fprintf( stderr, "illegal amplitude %s\n", argv[3] );
        return 1;
    } /*endif*/
    if  (sscanf(argv[4],"%f",&dist) != 1)  {
        fprintf( stderr, "illegal distance %s\n", argv[4] );
        return 1;
    } /*endif*/

    /*printf( "%s %f %f\n", magn, ampl, dist );*/

    status = 0;
    if  (strcmp(magn,"mb") == 0)
        m = magn_mb( ampl, period, dist, &status );
    else
        m = magn_ms_plain( ampl, period, dist, &status );
    if  (status == 0)
        printf( "%4.2f\n", m );
    else
        printf( "status %d\n", status );

}
