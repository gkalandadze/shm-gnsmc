#! /usr/bin/env python

"""
Checks meta information for completeness (more or less). Uses a simple
approach: Parses STATINF.DAT (or similar). If the station is not listed
in filter_lookup and/or sensitivities, it's incomplete.
"""

import sys

default = ["STATINF2.DAT", "filter_lookup.txt", "sensitivities.txt"]
#default = ["LocalStatinf.dat", "LocalFilterLookup.dat", "LocalSensitivities.dat"]
# mappers reveal the station code
mappers = [
    lambda x: x.split()[0].upper(),
    lambda x: x.split('-')[0].upper(),
    lambda x: x.split('-')[0].upper()
]
target = ["PartialStatinf.dat", "PartialFilterLookup.dat",
                                                    "PartialSensitivities.dat"]
target2 = "NoMetaStatinf.dat"


def reader(fname, mapper=None):
    """
    Simple ascii file reader.
    """
    with open(fname) as f:
        data = f.readlines()

    if not callable(mapper):
        return data

    for _i, d in enumerate(data):
        d = d.strip()
        if not len(d):
            continue
        data[_i] = mapper(d)

    return data


def main():
    data = []
    for _i, _f in enumerate(default):
        _d = reader(_f, mappers[_i])
        _d = list(set(_d))
        data.append(_d)
#    import pdb; pdb.set_trace()

    out = []
    out2 = []
    for s in data[0]:
        missing = []
        found = []
        if s not in data[1]:
            missing.append(default[1])
        else:
            found.append(default[1])
        if s not in data[2]:
            missing.append(default[2])
        else:
            found.append(default[2])

        if not missing:
            continue

        print >> sys.stderr, "%s missing in %s" % (s, ",".join(missing))

        if len(missing) == 2:
            # nothing available
            out.append("^%s\W+" % s)
            continue
        else:
            # filter
#            if found[0] == default[1]:
#             sensitiviy
            if found[0] == default[2]:
                out2.append("^%s\W+" % s)

        print >> sys.stderr, missing, found

    # please redirect output to file and use grep -E for extraction
    # $ egrep -i -f regex STATINF.DAT
    # $ egrep -vi -f regex STATINF.DAT
#    print "|".join(out)
    print "|".join(out2)



if __name__ == "__main__":
    main()
