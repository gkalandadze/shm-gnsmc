#! /usr/bin/env python

"""
This script fetches inventory data via arclink for listed stations
and saves information in Seismic Handler's format.
"""

import os
import sys
import textwrap
import subprocess

try:
    from obspy.core import UTCDateTime
    from obspy.arclink import Client
    from obspy.sh.core import fromUTCDateTime
except ImportError:
    print "ObsPy modules not found! Pleae install them, see http://obspy.org/"
    quit(1)

def fetch(station, email):
    """
    Fetch actual station information including history
    """
    net, station = station.split('.')
    s = UTCDateTime(0)
    e = UTCDateTime()
    client = Client(user=email)
    inv = client.getInventory(net, station, '*', '*', s, e, instruments=True, \
                                                                   route=False)
    stations = [(i, inv[i]) for i in inv.keys() if len(i.split(".")) == 2]
    print "Fetched data for %u stations." % len(stations)
    channels = [(i, inv[i]) for i in inv.keys() if len(i.split(".")) > 2]
    print "Fetched data for %u channels." % len(channels)
    return (stations, channels)

def save_station(f, stations):
    print "Saving station information to %s..." % f.name
    for s in stations:
        s, d = s
        code = s.split('.')[1]

        print " %s" % s
        f.write("! %s (%s)\n" % (s, d.description))
        f.write("%s lat: %f lon: %f elevation: %.1f\n" % (
                             code, d.latitude, d.longitude, d.elevation)
        )

def save_sensitivity(f, channels):
    print "Saving sensitivity information to %s..." % f.name
    for c in channels:
        s, d = c
        net, code, location, channel = s.lower().split('.')
        print " %s" % s
        for t in d:
            l = []
            l.append('-'.join([code, channel[:2], channel[2]]))
            try:
                l.append(fromUTCDateTime(t.starttime))
            except:
                l.append('...')
            try:
                l.append(fromUTCDateTime(t.endtime))
            except:
                l.append('...')
            l.append("%.5f" % (1e9/t.gain))

            try:
                f.write("! %s\n" % t.paz.name)
            except:
                pass

            f.write("%s\n" % ("   ".join(l)))

def save_filters(filterlookup, channels):
    print "Saving filter information to %s..." % filterlookup.name
    filter_list = []
    channel_filters = []
    for c in channels:
        s, d = c
        net, code, location, channel = s.upper().split('.')

        print " %s" % s
        for t in d:
            flt = Filter(t.paz)
            # new filter?
            unique = True
            for f in filter_list:
                if f == flt:
                    unique = False
                    break

            if unique:
                filter_list.append(flt)
            else:
                flt = f

            flt.used.append(s)

            l = []
            l.append('-'.join([code, channel[:2], channel[2]]))
            l.append(flt)

            try:
                l.append(fromUTCDateTime(t.starttime))
            except:
                l.append('...')

            try:
                l.append(fromUTCDateTime(t.endtime))
            except:
                l.append('...')

            channel_filters.append(l)

    # save filters
    names = []
    for f in filter_list:
        f.comment = ' '.join(set(f.used))
        f.write(directory='/tmp')
        names.append(f.name)
        # make displacement filter
        f.zeros.append(0j)
        f.write(f.name, directory=f.directory, prefix='TF_DSP_S+', calculate=False)

    # save channel filter configuration
    for f in channel_filters:
        filterlookup.write("   ".join(map(str, f)))
        filterlookup.write('\n')

    return names


class Filter(object):
    def __init__(self, paz):
        self.zeros = paz.zeros[:]
        self.poles = paz.poles[:]
        self.magnification = 123
        self.used = []
        self.comment = ''
        self.name = None

    def write(self, name=None, directory='.', prefix='TF_VEL_S+', calculate=True):
        self.__comment = '\n'.join(["! %s" % i for i in textwrap.wrap(self.comment)])
        if name is None:
            # name = uuid.uuid4().hex
            name = os.urandom(3).encode('hex')
        self.name = name.upper()
        self.directory = directory
        self.__name = "%s%s" % (prefix, self.name)
        self.__filename = os.extsep.join([self.__name, 'FLF'])
        self._save()
        if calculate:
            self.calculate_magnification()
            self._save()

    def calculate_magnification(self):
        evalflf = os.path.join(os.getenv("SH_UTIL"), "evalflf")
        flt = os.path.join(self.directory, os.path.splitext(self.__name)[0])
        response = subprocess.Popen("%s %s 1" % (evalflf, flt), stdout=subprocess.PIPE, shell=True).stdout.read()
        self.magnification /= float(response.split()[0])

    def _save(self):
        try:
            f = open(os.path.join(self.directory, self.__filename), 'w')
        except:
            print "cannot save"
            self.name = None
            return

        f.write(self.__comment)
        f.write('\n')
        f.write('1357913578\n')
        f.write('1\n')
        f.write('%.5f\n' % self.magnification)
        f.write('%u\n' % len(self.zeros))
        for i in self.zeros:
            f.write('(%e,%e)\n' % (i.real, i.imag))
        f.write('%u\n' % len(self.poles))
        for i in self.poles:
            f.write('(%e,%e)\n' % (i.real, i.imag))
        f.close()


    def __eq__(self, other):
        if self.zeros != other.zeros:
            return False
        if self.poles != other.poles:
            return False
        if self.magnification != other.magnification:
            return False
        return True

    def __str__(self):
        if self.name is None:
            return "unsaved filter at %u" % id(self)
        else:
            return self.name


def main():
    # format is NETCODE.STATION - may contain wildcards
    print "="*72
    print " Arclink Seismic Handler inventory tool"
    print "="*72, "\n"

    if len(sys.argv) > 1 and "@" in sys.argv[1]:
        email = sys.argv[1]
    else:
        email = raw_input("Your e-mail address for arclink query: ")
        
    if len(sys.argv) > 2 and "." in sys.argv[2]:
        station = sys.argv[2]
    else:
        print "\nPlease enter the network and station code. It may contain wildcards,"
        print "e.g. 'EI.* for the whole irish network or 'GR.GRA1' for Graefenberg A1."
        station = raw_input("Enter code: ")
        print ""

    statinf = open('/tmp/STATINF.DAT', 'w')
    sensitivity = open('/tmp/sensitivities.txt', 'w')
    filters = open('/tmp/filter_lookup.txt', 'w')
    
    station = station.upper()
    s, c = fetch(station, email)

    if s:
        print ""
        save_station(statinf, s)
        save_sensitivity(sensitivity, c)
        names = save_filters(filters, c)

    statinf.close()
    sensitivity.close()
    filters.close()

    if not s:
        os.remove('/tmp/STATINF.DAT')
        os.remove('/tmp/sensitivities.txt')
        os.remove('/tmp/filter_lookup.txt')

        print "\nNo information for station %s found!\n" % station
        quit(2)
    
    print "\nNow check the files in /tmp/. Afterwards append the information to"
    print "the corresponding files in $SH_INPUTS. Alternatively configure"
    print "additional input locations. Copy the transfer function files to"
    print "$SH_FILTER."

    print "\nIn order to create simulation filters (e.g. WWSSN-SP), run the"
    print "following commands:\n"

    for n in names:
        print " $SH_UTIL/prep_simfilters.csh %s" % n

    print ""

if __name__ == "__main__":
    main()
