#! /usr/bin/env python
#
# file seedvol2gse.py
#      ==============
#
# version 1, 2-Jul-2007
#
# Convert seed volume to GSE using SH
# K. Stammler, 2-Jul-2007

import sys
import os

#-------------------------------------------------------------------------------

# check for parameters
if  len(sys.argv) < 2:
	print "Usage:", sys.argv[0], "<seedvol>"
	sys.exit()
else:
	seedvol = sys.argv[1]

os.system( "$SEED_PROG/seed2sfd "+seedvol+" >sfdfile.sfd\n"
	+"$SH_UTIL/sfd2readall.py sfdfile.sfd .>SEEDVOL.SHC\n"
	+"$SH_ROOT/shc_world <<EOF\n"
	+"SEEDVOL\n"
	+"@WRITEGSE SEEDVOL.GSE\n"
	+"QUIT Y\n"
	+"EOF\n" )

os.remove( "sfdfile.sfd" )
os.remove( "SEEDVOL.SHC" )
os.system( "cat SEEDVOL.GSE" )
os.remove( "SEEDVOL.GSE" )
