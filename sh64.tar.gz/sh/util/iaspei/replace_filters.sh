#! /bin/bash

#set -x

echo "This tool replaces all present filter files in \$SH_FILTER using the"
echo "IASPEI recommendations. For details please have a look at"
echo -e "http://www.iaspei.org/commissions/CSOI/Summary_WG-Recommendations_20110909.pdf\n"
echo "Changes in frequency character are only small in relevant ranges,"
echo -e "but be careful if you perform statistical analysis on magnitudes!\n"

auto=$1
single=$2
target=$SH_FILTER/iaspei
backup=$SH_FILTER/backup
review=0

# check for write access
if [ ! -w $SH_FILTER/DUMMY.FLF ] ; then
    echo "No write permission in \$SH_FILTER directory!"
    exit 1
fi

if [ "$auto" != "auto" ] ; then
    read -N 1 -p "Continue [yN]? " cc
    [ "$cc" != "y" ] && exit 2
    echo ""
    read -N 1 -p "Review new versus backup filter characteristic [Yn]? " cc
    [ "$cc" != "n" ] && review=1
    echo -e "\n"
fi

# check for filter files: if $target exists assume that filters are
# already present in local installation
if [ ! -d $target ] ; then
    mkdir $target
    tmp=`mktemp -d`
    echo "New filter files not present in active installation!"
    echo "Downloading from internet to $tmp ..."
    cd $tmp
    baseuri="https://www.seismic-handler.org/svn/SH_SHM/tags/2012a/filter/iaspei/"
    wget -q ${baseuri}TF_DSP_S%2BWOODAND_IASPEI.FLF || exit 3
    wget -q ${baseuri}TF_DSP_S%2BWWSSN_LP_IASPEI.FLF || exit 3
    wget -q ${baseuri}TF_DSP_S%2BWWSSN_SP_IASPEI.FLF || exit 3
    wget -q ${baseuri}TF_VEL_S%2BWOODAND_IASPEI.FLF || exit 3
    wget -q ${baseuri}TF_VEL_S%2BWWSSN_LP_IASPEI.FLF || exit 3
    wget -q ${baseuri}TF_VEL_S%2BWWSSN_SP_IASPEI.FLF || exit 3
    wget -q ${baseuri}BP_BORDERS_WOODAND.FLF || exit 3

    cp *.FLF $target
    rm -rf $tmp
fi

cd $SH_FILTER

# WOODAND *has* to be first one!
filters=( S+WOODAND S+G_WWSSN_SP S+WWSSN_LP )
new_filters=( S+WOODAND_IASPEI S+WWSSN_SP_IASPEI S+WWSSN_LP_IASPEI )

echo -e "Replacing current filter sets (backup in $backup)...\n"

[ -d $backup ] || mkdir $backup
for i in $(seq 0 $((${#filters[@]}-1))) ; do
    f=${filters[$i]}
    echo "Processing $f ..."

    # backup all filter files containing filter name
    cp *${f}*.FLF $backup
    [ $? -ne 0 ] && exit 4

    # overwrite current basic filters
    cp $target/TF_VEL_${new_filters[$i]}.FLF TF_VEL_${f}.FLF

    # BP for WOODAND = first loop
    bandpass=0
    [ $i -eq 0 ] && bandpass=1

    for x in *${f}*.FLF ; do
        # skip symbolic links
        [ -h $x ] && continue

        filtername=`basename $x .FLF`
        of=`basename $x _${filters[$i]}.FLF`
        # skip simulation filter file
        [ "$of" = "TF_VEL" ] && continue
        [ "$of" = "TF_DSP" ] && continue

        echo -e "\n --> $of and $f ..."

        # get transfer function
        tf="TF_VEL_S+${of}.FLF"
        # fall-back
        [ ! -e $tf ] && tf="TF_VEL_${of}.FLF"

        ok=0
        operation=0
        while [ $ok -eq 0 ] ; do
            if [ "$operation" == "0" ] ; then
                if [ ! -e $tf ] ; then
                    echo -e "\nWarning: Transfer function for $of not found!"
                    echo -e "It will be created out of the simulation filter file...\n"
                    echo '! Created from simulation file because transfer function was missing!' > $tf
                    $SH_UTIL/catflf backup/TF_VEL_$f div $filtername >> $tf
                fi

                # combine filter
                $SH_UTIL/catflf TF_VEL_$f div `basename $tf .FLF` > $x

                # apply BP on WOODAND?
                if [ $bandpass -ne 0 ] ; then
                    temp=${filtername}_x.FLF
                    cp $x $temp
                    head -2 $temp > $x
                    $SH_UTIL/catflf ${filtername}_x mul iaspei/BP_BORDERS_WOODAND >> $x
                    rm $temp
                fi
            fi

            tfname=`basename $tf .FLF`

            if [ $review -ne 0 ] ; then
                operation=0
                $SH_UTIL/filtgraph.csh TF_VEL_$f,$tfname,$filtername,backup/$filtername 0.0001 1000 1e-7 10000
                read -N 1 -p "[A]ccept, [D]elete, use input from former [S]imulation filter, [O]perations, e[X]it? " cc
                echo ""
                [ "$cc" = "a" ] && ok=1
                [ "$cc" = "d" ] && rm $x && ok=1
                [ "$cc" = "x" ] && exit
                [ "$cc" = "s" ] && tf=TF_VEL_${of}_RECOVERED.FLF
                [ "$cc" = "o" ] && operation=1
            elif
                ok=1
            fi

            rm -f tmpfil_*.FLF

            # always continue except if operation requested
            [ $operation -eq 0 ] && rm -f *_operation.FLF && continue

            # restore backup'd filter file
            [ -e ${filtername}_operation.FLF ] && cp ${filtername}_operation.FLF $x

            frq2=""
            mode=""
            read -N 1 -p "Choose type: high-pass (h), low-pass (l), bandpass (b), other: restart: " cc
            echo ""
            if [ "$cc" == "h" ] ; then
                read -p "Enter high-pass frequency (Hz): " frq1
                mode="hp"
            elif [ "$cc" == "l" ] ; then
                read -p "Enter low-pass frequency (Hz): " frq1
                mode="lp"
            elif [ "$cc" == "b" ] ; then
                read -p "Enter lower boundary (Hz): " frq1
                read -p "Enter upper boundary (Hz): " frq2
                mode="bp"
            else
                echo "Starting over..."
                operation=0
                continue
            fi
            read -p "Enter order (default 3): " order
            [ "$order" == "" ] && order=3

            TMPFIL="tmpfil_${mode}_${frq1}_${frq2}_${order}"
            $SH_UTIL/butfreq $mode f $frq1 $frq2 -f=$TMPFIL -o=$order

            cp $x ${filtername}_operation.FLF
            awk '$1 == "!" {print}' ${filtername}_operation.FLF > $x
            $SH_UTIL/catflf ${filtername}_operation mul $TMPFIL >> $x
        done
    done
done

# clean-up
rm -f *_operation.FLF tmpfil_*.FLF
