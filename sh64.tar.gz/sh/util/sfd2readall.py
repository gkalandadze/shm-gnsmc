#! /usr/bin/env python
#
# file sfd2readall.py
#      ==============
#
# version 1, 2-Jul-2007
#
# Takes sfd file and creates read commands for each line of it
# K. Stammler, 2-Jul-2007

import sys
import os
import datetime

#-------------------------------------------------------------------------------



def Sh2Datetime( shtime ):
	"""Convert SH time string to datetime.

	shtime:  SH time string
	"""
	
	x = os.popen( "$SH_UTIL/timename time_to_int "+shtime ).readlines()
	if len(x) < 1:
		print 'Sh2Datetime failed on', '>', shtime, '<'
		return None
	y = x[0].rstrip()
	res = y.split( " " )
	if  (len(res) < 7):
		print "Syntax error in shtime:", shtime
		sys.exit()
	year, month, day, hour, minute, sec, ms = res
	s_time = datetime.datetime( int(year), int(month), int(day), int(hour), \
		int(minute), int(sec), int(ms)*1000 )
	return s_time



#-------------------------------------------------------------------------------

# check for parameters
if  len(sys.argv) < 3:
	print "Usage: %s <sfdfile> <readdir>" % sys.argv[0]
	sys.exit()

sfdfile = sys.argv[1]	
readdir = sys.argv[2]

if  not os.path.exists(sfdfile):
	print "file", sfdfile, "not found abort"
	sys.exit()
	
print "nr"

sfd = open( sfdfile )
for line in sfd.readlines():
	idx = line.find("s>")
	stream = line[idx+2:].split()[0]
	idx = line.find("b>")
	stime = line[idx+2:].split()[0]
	idx = line.find("e>")
	etime = line[idx+2:].split()[0]
	timewdw = Sh2Datetime( etime ) - Sh2Datetime( stime )
	rwdw = float(timewdw.seconds) + float(timewdw.microseconds)/1000000.0
	s = stream.split("-")
	if  len(s) != 3:  continue
	print "reads/noswap", readdir, stime, rwdw, s[0], s[2], s[1]

sfd.close()

print "rd"
print "rd"
print "return"
	
