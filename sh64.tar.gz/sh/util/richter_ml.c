
/* file richter_ml.c
 *      ============
 *
 * $Revision$, $Date$
 *
 * Compute Richter magnitude ml
 * K. Stammler, 9-Nov-2008
 */

#include <string.h>
#include <stdio.h>
#include <math.h>

#define Nint(x) ((x)>0 ? (int)((x)+0.5) : (int)((x)-0.5))

static float ml_sigma[] = {
	1.4,1.4,1.5,1.6,1.7,1.9,2.1,2.3,2.4,2.5,2.6,2.7,2.8,2.8,2.8,
	2.8,2.9,2.9,3.0,3.0,3.0,3.1,3.1,3.2,3.2,3.3,3.3,3.4,3.4,3.5,
	3.5,3.6,3.65,3.7,3.7,3.8,3.8,3.9,3.9,4.0,4.0,4.1,4.1,4.2,4.2,
	4.3,4.3,4.3,4.4,4.4,4.5,4.5,4.5,4.6,4.6,4.6,4.6,4.7,4.7,4.7,
	4.7,4.8,4.8,4.8,4.8,4.8,4.9,4.9,4.9,4.9,4.9,5.2,5.4,5.5,5.7
};
#define cSiMlSigmaLth 75

/* local prototype */
float magn_ml( float ampl, float distance, int *dist_ok );


int main( int argc, char *argv[] )
{
	/* local variables */
	float    ampl;         /* amplitude */
	float    dist;         /* distance in km */
	float    ml;           /* magnitude */
	int      ok;           /* distance ok? */

	/* executable code */

	if  (argc != 3)  {
		fprintf( stderr, "Usage: %s <ampl> <km-distance>\n", argv[0] );
		return 1;
	} /*endif*/

	if  (sscanf(argv[1],"%f",&ampl) != 1)  {
		fprintf( stderr, "illegal amplitude %s\n", argv[1] );
		return 1;
	} /*endif*/
	if  (sscanf(argv[2],"%f",&dist) != 1)  {
		fprintf( stderr, "illegal distance %s\n", argv[2] );
		return 1;
	} /*endif*/

	ml = magn_ml( ampl, dist, &ok );
	if  (ok)  {
		printf( "%4.2f\n", ml );
	} /*endif*/

} /* end of main */


/*----------------------------------------------------------------------------*/


#define MAGN_ML_MIN_DIST 1.0
#define MAGN_ML_MAX_DIST 1000.0

float magn_ml( float ampl, float distance, int *dist_ok )

/* Returns magnitude ml.  Amplitude and period must be read from a WOOD-ANDERSON
 * simulated seismogram, horizontal component.
 *
 * parameters of routine
 * float      ampl;        input; amplitude of WOOD-ANDERSON simulation
 * float      distance;    input; epicentral distance in km
 * int        *dist_ok;    output; input distance valid?
 *                         returns value of ml
 */
{
	/* ml distance correction (C.F.RICHTER (1958): Elementary 
	 * Seismology. p 342, up to 600 km epicentral distance,
	 * G.SCHNEIDER (1975): Erdbeben. p.338, from 700 up to 1000 km
	 * epicentral distance)
	 */

	/* local variables */
	int      idist;        /* rounded distance */
	float    delta;        /* step size */
	int      ioffset;      /* index offset */
	float    grad;         /* gradient */
	int      itmp;         /* scratch */
	float    tmp;          /* scratch */

	/* executable code */

	/* check distance */
	*dist_ok = 1;
	if  (distance < MAGN_ML_MIN_DIST || distance >= MAGN_ML_MAX_DIST)  {
		*dist_ok = 0;
		return 0.0;
	} /*endif*/

	/* get step size */
	if  (distance > 600.0)  {
		delta = 100.0;
		ioffset = 64;
	} else if  (distance > 100.0)  {
		delta = 10.0;
		ioffset = 10;
	} else {
		delta = 5.0;
		ioffset = 0;
	} /*endif*/

	itmp = Nint( floor(distance/delta) );
	idist = itmp + ioffset;
	grad = ( ml_sigma[idist+1] - ml_sigma[idist] ) / delta;
	tmp = distance - (float)itmp*delta;
	tmp = ml_sigma[idist] + tmp*grad;

	tmp += log10((double)ampl);

	return tmp;

} /* end of magn_ml */



#undef MAGN_ML_MIN_DIST
#undef MAGN_ML_MAX_DIST

/*----------------------------------------------------------------------------*/


