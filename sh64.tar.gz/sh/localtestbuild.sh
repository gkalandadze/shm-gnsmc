#! /bin/bash

# This script copies all changed files to the current SH installation
# and starts the compilation. So mistakes in recent changes will be
# visible before version control check-in. Removed files will also be
# deleted in $SH_ROOT - so be careful while using this script. It might
# mess up your current installation of SH(M) completely. Of course you
# need write rights inside $SH_ROOT directory. It's recommended to use
# it only on a local personal installation tree.
#
# This script is far away from being perfect - it's just a helper tool
# to make life a little easier.
#
# Marcus Walther, 18. Aug 2011

svn st | while read status filename ; do
    # skip blank directories (mostly property changes)
    [ -d $filename ] && continue

    # skip all files starting with dot (hidden, etc)
    fs=`basename $filename | cut -b 1`
    [ "$fs" = "." ] && continue

    # copy files
    [ "$status" = "?" ] && cp -v $filename $SH_ROOT/$filename
    [ "$status" = "M" ] && cp -v $filename $SH_ROOT/$filename
    [ "$status" = "A" ] && cp -v $filename $SH_ROOT/$filename

    # delete files
    [ "$status" = "D" ] && rm -f $SH_ROOT/$filename
done

cd $SH_ROOT

tcsh -c make

