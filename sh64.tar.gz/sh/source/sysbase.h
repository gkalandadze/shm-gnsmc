
/* file SYSBASE.H
 *      =========
 *
 * version 24, 22-May-2006
 *
 * v 21: 28-Nov-94, K. Stammler: new naming conventions on sun
 *
 * machine dependent definitions
 * this file conatins all available implementations
 * K. Stammler, 2-MAY-90
 */


/*
 *
 *  SeismicHandler, seismic analysis software
 *  Copyright (C) 1996,  Klaus Stammler, Federal Institute for Geosciences
 *                                       and Natural Resources (BGR), Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stdlib.h>

#ifndef __SYSBASE
#define __SYSBASE

#ifndef __BASECNST
#include "basecnst.h"
#endif

/* short integer */
#define BYTE unsigned char
#define TSyByte BYTE
#define TSyWord short int
#define TSyUword unsigned short int

/* boolean type */
#define BOOLEAN int
#define TSyBoolean BOOLEAN

/* boolean values TRUE & FALSE */
#ifdef BC_DEFINE_TRUE_FALSE
#define TRUE (1)
#define FALSE (0)
#endif
#define cSyTrue (1)
#define cSyFalse (0)

/* infinite loop declaration */
#define FOREVER for(;;)
#define TSyForever FOREVER

/* status type */
#ifndef STATUS
#define STATUS int
#define Severe(s) (*(s) != 0)
#define TSyStatus STATUS
#define SySevere(s) (*(s) != 0)
#endif /* TSyStatus */

/* nearest integer number to floating number */
#define Nint(x) ((x)>0 ? (int)((x)+0.5) : (int)((x)-0.5))
#define Nint32(x) ((x)>0 ? (int)((x)+0.5) : (int)((x)-0.5))
#define SyNint(x) ((x)>0 ? (int)((x)+0.5) : (int)((x)-0.5))

/* nearest long number to floating number */
#define Nlong(x) ((x)>0 ? (long)((x)+0.5) : (long)((x)-0.5))
#define SyNlong(x) ((x)>0 ? (long)((x)+0.5) : (long)((x)-0.5))

/* capitalize character */
#define Cap(c) (((c)>='a' && (c)<='z') ? ((c)-32) : (c))
#define SyCap(c) (((c)>='a' && (c)<='z') ? ((c)-32) : (c))
#define Uncap(c) (((c)>='A' && (c)<='Z') ? ((c)+32) : (c))
#define SyUncap(c) (((c)>='A' && (c)<='Z') ? ((c)+32) : (c))

/* absolute value of number */
#define Abs(x) ((x)<0?-(x):(x))
#define SyAbs(x) ((x)<0?-(x):(x))

/* binary file type, here the same as text file */
typedef FILE *BFILE;
#define TSyBfile BFILE

/* sy_findfile parameter */
#define SYC_FF_NAME 1
#define SYC_FF_DIR 2
#define SYC_FF_EXT 4
#define cSyFfName 1
#define cSyFfDir 2
#define cSyFfExt 4

/* deallocate memory */
#define sy_deallocmem(p) free(p)
#define SyDeallocMem(p) free(p)

/* read logical name table */
#define sy_lognames(f,s) fo_readtable(f,s)
#define SyLogNames(f,s) fo_readtable(f,s)

/* open text file */
/* #define sy_fopen(f,a) fo_fopen(f,a) */
/* routine implemented for it */

/* close text file */
#define sy_fclose(f) fclose(f)
#define SyFclose(f) fclose(f)

/* read from text file */
#define sy_fread(b,s,n,f) fread(b,s,n,f)
#define SyFread(b,s,n,f) fread(b,s,n,f)

/* write to text file */
#define sy_fwrite(b,s,n,f) fwrite(b,s,n,f)
#define SyFwrite(b,s,n,f) fwrite(b,s,n,f)

/* read from binary file */
#define sy_fbread(b,s,n,f) fread(b,s,n,f)
#define SyFbread(b,s,n,f) fread(b,s,n,f)

/* write to binary file */
#define sy_fbwrite(b,s,n,f) fwrite(b,s,n,f)
#define SyFbwrite(b,s,n,f) fwrite(b,s,n,f)

/* seek on binary file */
#define sy_fbseek(f,p,m) fseek(f,p,m)
#define SyFbseek(f,p,m) fseek(f,p,m)

/* open binary file */
#define sy_fbopen(f,a) sy_fopen(f,a)
#define SyFbopen(f,a) sy_fopen(f,a)

/* close binary file */
#define sy_fbclose(f) fclose(f)
#define SyFbclose(f) fclose(f)

/* binary file operation failed */
#define sy_fbfailed(f) ((f)==NULL)
#define SyFbfailed(f) ((f)==NULL)

/* call to operating system */
#define sy_system(c,s) system(c)
#define SySystem(c,s) system(c)

/* delete file */
#define sy_fdelete(f) unlink(f)
#define SyFdelete(f) unlink(f)

/* rename file */
#define sy_frename(f,t) rename(f,t)
#define SyFrename(f,t) rename(f,t)

/* difference time, not implemented */
#define sy_difftime() 1.0
#define SyDifftime() 1.0


/* system constants */
/* ---------------- */

/* maximum unsigned */
#define SYC_MAXUNSG 0xffffffffL
#define cSyMaxUnsg SYC_MAXUNSG

/* maximum integer */
#define SYC_MAXINT 0x7fffffffL
#define cSyMaxInt SYC_MAXINT

/* minimum integer */
#define SYC_MININT 0x80000000L
#define cSyMinInt SYC_MININT

/* maximum long */
#define SYC_MAXLONG 0x7fffffffL
#define cSyMaxLong SYC_MAXLONG

/* minimum long */
#define SYC_MINLONG 0x80000000L
#define cSyMinLong SYC_MINLONG

/* open existing file to overwrite */
#define SYC_OPEN_OVWR "r+"
#define cSyOpenOvwr SYC_OPEN_OVWR


/* system specific types */
/* --------------------- */

/* difference time */
typedef float DIFFTIME;
typedef float TSyDifftime;


/* not implemented routines */
#define sy_gettime(s) strcpy(s,SHC_TIMEDEFAULT)
#define SyGetTime(s) strcpy(s,SHC_TIMEDEFAULT)
#define sy_sharecpu()
#define SyShareCpu()
#define sy_alert(t) printf("%s",t)
#define SyAlert(t) printf("%s",t)
#define sy_initprocess()
#define SyInitProcess()


/* include fileopen */
#ifndef __FOUSRDEF
#include BC_FOUSRDEF
#endif


/*------------------------------------------------------------------------*/
/*    prototypes of routines of module SYSCALL.C                          */
/*------------------------------------------------------------------------*/


#define SyAllocMem sy_allocmem

void *sy_allocmem( long cnt, int size, STATUS *status );

/* allocates memory ("cnt" objects of size "size)
 *
 * parameters of routine
 * long     cnt;            input; number of objects
 * int      size;           input; size of each object
 * STATUS   *status;        output; return status
 */


/*------------------------------------------------------------------------*/


#define SyFindFile sy_findfile

void sy_findfile( int request, char wild[], char filename[] );

/* looks for files matching wild card string "wild". Returns filename of
 * file found or "\0" if not found.  "request" controls the returned
 * elements.  For example the value (SYC_FF_DIR|SYC_FF_NAME|SYC_FF_EXT)
 * means, that the returned string contains directory, file name and
 * extension.
 *
 * parameters of routine
 * int      request;        input; what elements (name,dir,extension)
 * char     *wild;          input; wild card string
 * char     *filename;      output; next file found
 */


/*------------------------------------------------------------------------*/


#define SyFopen sy_fopen

FILE *sy_fopen( char file[], char access[] );

/* opens file.  Backslashes "\" in the filename are converted to slashes "/"
 *
 * parameters of routine
 * char       file[];        input; filename of file to be opened
 * char       access[];      input; access string
 *                           returns pointer to file or NULL
 */


/*------------------------------------------------------------------------*/


#define SyRandom sy_random

double sy_random( double ampl );

/* creates random number with absolute value less than (or equal to)
 * "amp"
 *
 * parameters of routine
 * double		ampl;		input; max. amplitude; if zero, a new random
 * 									 series is started
 */


/*------------------------------------------------------------------------*/


#define SyRandomStr sy_randomstr

void sy_randomstr( int lth, char str[] );

/* creates random string of length "lth"
 *
 * parameters of routine
 * int        lth;      input; length of output string
 * char       str[];    output; random string
 */


/*------------------------------------------------------------------------*/


#define SyLocalInf sy_localinf

void sy_localinf( char item[], char value[], STATUS *status );

/* returns local info in "value"
 *
 * parameters of routine
 * char       item[];     input; info item
 * char       value[];    output; return value
 * STATUS     *status;    output; return status
 */


/*------------------------------------------------------------------------*/


#endif /* __SYSBASE */

