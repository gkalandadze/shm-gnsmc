/* file BASECNST.H
 *      ==========
 *
 * version 47, 1-May-2007
 *
 * v 36: 28-Nov-94, K. Stammler, new naming conventions
 *
 * basic constants for all modules
 * K. Stammler, 22-MAY-91
 */


/*
 *
 *  SeismicHandler, seismic analysis software
 *  Copyright (C) 1996,  Klaus Stammler, Federal Institute for Geosciences
 *                                       and Natural Resources (BGR), Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


#ifndef __BASECNST
#define __BASECNST


/* some constants */

/* old style names */
#define BC_LINELTH 199
#define BC_SHORTSTRLTH 30
#define BC_LONGSTRLTH 2047
#define BC_VERYLONGSTRLTH 8191
#define BC_TIMELTH 30
#define BC_FILELTH 179
#define BC_NOERROR 0
#define BC_PI 3.14159265358979323846
/* new style names */
#define cBcLineLth BC_LINELTH
#define cBcShortStrLth BC_SHORTSTRLTH
#define cBcLongStrLth BC_LONGSTRLTH
#define cBcVeryLongStrLth BC_VERYLONGSTRLTH
#define cBcTimeLth BC_TIMELTH
#define cBcFileLth BC_FILELTH
#define cBcNoError BC_NOERROR
#define cBcPi BC_PI


/******************************************************************
 ***                  computer type and graphics                ***
 ******************************************************************/

/* select graphics */
#define BC_G_MEM
#define cBc_G_MEM
#define BC_G_POSTSCRIPT
#define cBc_G_POSTSCRIPT
#define BC_G_XWINDOW
#define cBc_G_XWINDOW

/* general flags */
/* #define BC_MAINARGS */
/* #define cBc_MAINARGS */
#define BC_STDLIB_EX   /* should not be used any more */

/* for some historical reasons ... */
#define BC_INC_STDLIB <stdlib.h>
#define cBc_INC_STDLIB BC_INC_STDLIB
#define BC_INC_UNISTD <unistd.h>
#define cBc_INC_UNISTD BC_INC_UNISTD

/* compile AH interface ? */
#if  defined(SH_SETUP_AH)
#define BC_FRGN_AH
#define cBc_FRGN_AH
#endif

/* special settings */
#define BC_REVERSECROSS
#define cBc_REVERSECROSS
	/* crosshair cursor colours reversed (background and foreground) */
#define BC_DEFINE_TRUE_FALSE
#define cBc_DEFINE_TRUE_FALSE
	/* define TRUE and FALSE */
/* #define BC_CLOCK_T_AVAILABLE */
	/* type clock_t is available */

/* only old style names */
#define BC_SYSBASE "sysbase.h"
#define BC_SYERRORS "syerrors.h"
#define BC_GCUSRDEF "gcusrdef.h"
#define BC_GCERRORS "gcerrors.h"
#define BC_SHDIRS "shdirs.h"
#define BC_ASCII "ascii.h"
#define BC_GRAPHBAS "graphbas.h"
#define BC_SHCONST "shconst.h"
#define BC_QFUSRDEF "qfusrdef.h"
#define BC_QFERRORS "qferrors.h"
#define BC_CPAR "cpar.h"
#define BC_EARTHLOC "earthloc.h"
#define BC_UTUSRDEF "utusrdef.h"
#define BC_GLUSRDEF "glusrdef.h"
#define BC_INPFILES "inpfiles.h"
#define BC_TCUSRDEF "tcusrdef.h"
#define BC_DFQENTRY "dfqentry.h"
#define BC_FOUSRDEF "fousrdef.h"
#define BC_ERUSRDEF "erusrdef.h"
#define BC_FLERRORS "flerrors.h"
#define BC_READGRN "readgrn.h"
#define BC_PTUSRDEF "ptusrdef.h"

/* if no foreign formats are used: */
/* #define BC_FOREIGN "shfrgn.h" */
/* otherwise: */
#define BC_FOREIGN "shfrgn.h"
#define cBc_FOREIGN BC_FOREIGN


/******************************************************************
 ***                              END                           ***
 ******************************************************************/


#endif /* __BASECNST */


