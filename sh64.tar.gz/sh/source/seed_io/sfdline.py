#! /usr/bin/env python

import sys
import os
from obspy.core import read
from obspy.sh.core import fromUTCDateTime

def process_mseed(*args, **kwargs):
    """
    Output information about mseed file for Seismic Handler's seed reading
    routine.

    Output may be redirected to file (second argument).
    """

    try:
        stream = read(args[0], format="MSEED")
    except:
        quit("Cannot read input file: '%s'" % args[0])

    if len(args) == 2:
        mode = kwargs["overwrite"] and "w" or "a"
        try:
            out = open(args[1], mode)
        except:
            quit("Cannot write to output file '%s'" % args[1])
    else:
        out = sys.stdout

    # shortcut
    sts = stream[0].stats

    info = {
        # station + channel + component
        "s": ("-".join([sts.station, sts.channel[:2], sts.channel[2]])).lower(),
        # file
        "n": args[0],
        # starttime
        "b": fromUTCDateTime(sts.starttime),
        # endtime
        "e": fromUTCDateTime(sts.endtime),
        # number of records (file size / reclen)
        "r": str(os.stat(args[0])[6] / sts.mseed.record_length),
        # header swap
        "h": sts.mseed.byteorder == ">" and "0" or "1",
        # record length
        "l": sts.mseed.record_length,
        # byte offset (always zero)
        "o": "0",
        # network and location code
        "a": ((not sts.network and "  " or sts.network) + \
             (not sts.location and "  " or sts.location)).replace(" ", "."),
    }

    # "standard" order of fields (SH doesn't care about it, but maybe others)
    order = "snberhlo"
    if kwargs["netloc"]:
        order += "a"

    for i in order:
        print >> out, "%s>%s" % (i, info[i]),
    print >> out, ""

    # close output file if not stdout
    if out != sys.stdout:
        out.close()

if __name__ == "__main__":
    from optparse import OptionParser

    parser = OptionParser(usage="%prog [options] seedfile [outfile]")

    parser.add_option("--no-netloc",
        action="store_false", dest="netloc", default=True,
        help="Do not list network and location code.")

    parser.add_option("--overwrite",
        action="store_true", dest="overwrite", default=False,
        help="Overwrite outfile file (if given). Default will append "
             "information to exiting file.")

    (opts, args) = parser.parse_args()

    if not len(args):
        parser.error("Missing MSEED file for inspection.")

    if len(args) == 1 and opts.overwrite:
        parser.error("Option 'overwrite' set, but no output file given!")

    process_mseed(*args, **vars(opts))
