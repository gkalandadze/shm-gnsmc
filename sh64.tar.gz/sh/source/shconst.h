
/* file SHCONST.H
 *      =========
 *
 * $Revision: 406 $, $Date: 2013-02-07 16:03:35 +0100 (Do, 07. Feb 2013) $
 *
 * constants of seismhandler program
 * K. Stammler, 22-MAY-91
 */


/*
 *
 *  SeismicHandler, seismic analysis software
 *  Copyright (C) 1996,  Klaus Stammler, Federal Institute for Geosciences
 *                                       and Natural Resources (BGR), Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


#ifndef __SHCONST
#define __SHCONST

#define SHC_VERSION "2013a"
	/* version number */
#define TW 1
	/* text window */
#define GW 2
	/* graphics window */
#define SHC_FILE_PREFIX "SH_"
	/* file prefix of all SeismicHandler files */
#define SHC_FILE_PREFIX_LENGTH 3
	/* length of file prefix */
#define SHC_DE_TEXT ".STX"
	/* default extension of echo files */
#define SHC_DE_HELP ".HLP"
	/* default extension of help files */
#define SHC_DE_SAVE ".SSV"
	/* default extension of save files */
#define SHC_DE_CMD ".SHC"
	/* default command file extension */
#define SHC_DE_VEL ".VEL"
	/* default velocity file extension */
#define SHC_DE_ERROR ".MSG"
   /* default extension of error message files */
#define SHC_DE_RFILT ".FLR"
	/* default extension for recursive filter files */
#define SHC_DE_FFILT ".FLF"
	/* default extension for FFT filter files */
#define SHC_DE_DFILT ".FLT"
	/* default extension for tabulated filter files */
#define SHC_DE_CURVE ".CRV"
	/* default extension of curve files */
#define SHC_CHWRITE '&'
	/* write access character */
#define SHC_SYMGLB 1
	/* global symbol set number */
#define SHC_SYMLOC 0
	/* local symbol set number */
#define SHC_ILISTLTH 65000
	/* max length of integer lists */
#define SHC_CRSR '*'
	/* cursor input */
#define SHC_ABORTCH 'X'
	/* cursor input aborted */
#define SHC_EXITCH 'E'
	/* cursor input end */
#define SHC_TIMEDEFAULT "1-JUL-1970_12:00:00.00"
	/* trace start time default */
#define SHC_PI 3.14159265358979323846
	/* pi */
#define SHC_EPSILON 1.0e-25
	/* epsilon value */
#define SHC_RAD_TO_DEG (180.0/SHC_PI)
	/* conversion factor from radians to degrees */
#define SHC_DEG_TO_KM 111.19
	/* conversion factor degrees to km */
/* #define SHC_CURRDSP -1 */
	/* take trace from current display list */
/* #define SHC_HIDDENLIST -2 */
	/* take trace from hidden list */
#define SHC_MAXWDW 7
	/* maximum number of windows (same as in gcusrdef.h) */
#define SHC_WDWMASK 7
	/* window mask */
#define SHC_MAXDLN (SHC_MAXWDW+3)
	/* maximum display list number */
#define SHC_CARRIAGE_RETURN (char)13
	/* carriage return */
#define SHC_CHATTXT "   !i:"
	/* intro string for CHATTY output line */
#define SHC_STATNAMELTH 11
	/* maximum length of station name */

/* style numbers */
#define SHC_TITLESTYLE 8
	/* title style */
#define SHC_TRCINFOSTYLE 9
	/* style of trace info text */
#define SHC_ZEROTRCSTYLE 8
	/* style of zero trace lines */
#define SHC_MARKSTYLE 6
	/* style of markers */
#define SHC_PMSTYLE 5
	/* particle motion style */
#define SHC_TIMEAXISSTYLE 7
	/* style block of time axis */

/* #define SHC_HCFILE_WITH_RANDOM */

/* normalization types */
#define SHC_N_SF 0
#define SHC_N_SW 1
#define SHC_N_AF 2
#define SHC_N_AW 3
#define SHC_N_LF 4
#define SHC_N_LW 5
#define SHC_N_C  6

/* rotation types */
#define SHC_ROT_ZNE_TO_LQT 1
#define SHC_ROT_ZNE_TO_UVW 2
#define SHC_ROT_UVW_TO_ZNE 3

#define SHC_FILELTH 179
	/* maximum length of filenames */

/* flags */
typedef int SHFLAGS;
#define SHF_LOGCMD     0x1
#define SHF_ECHO       0x2
#define SHF_CAPCNV     0x4
#define SHF_STEP       0x8
#define SHF_VERIFY     0x10
#define SHF_CMDERRSTOP 0x20
#define SHF_SHERRSTOP  0x40
#define SHF_NOERRMSG   0x80
#define SHF_CHATTY     0x100
#define SHF_STARTUP    0x200


/* =========================== */
/* definitions of global types */
/* =========================== */

typedef float SAMPLE;   /* data type of seismogram samples */
typedef float REAL;     /* general floating point type */
/* typedef void TRACE; */    /* trace type (only used as pointer) */
#define TRACE void
#define SHENTRY unsigned
#define SHC_SAMPLEFMT "%e"
#define SHC_REALFMT "%e"

typedef struct sh_complex {
	REAL    re;    /* real part */
	REAL    im;    /* imaginary part */
} COMPLEX;


#endif /* __SHCONST */
