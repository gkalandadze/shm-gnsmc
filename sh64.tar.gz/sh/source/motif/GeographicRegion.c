
/* file GeographicRegion.c
 *      ==================
 *
 * version 1, 28-Oct-2010
 *
 * Retrieve name of geographic region from lat and lon.
 * K. Stammler, 28-Oct-2010
 */


#include <stdio.h>
#include <string.h>

void get_geo(float *elat, float *elon, int *num_id, char *qnam);

int main( int argc, char *argv[] )
{
    /* local variables */
    float    lat, lon;     /* epicentre location */
    int      regid;        /* region ID */
    char     regname[300]; /* region name */

    /* executable code */

    if  (argc < 3)  {
        fprintf( stderr, "Usage: %s <lat> <lon>\n", argv[0] );
        return 0;
    } /*endif*/

    if  (sscanf( argv[1], "%f", &lat ) != 1)  {
        fprintf( stderr, "cannot read lat\n" );
        return 1;
    } /*endif*/
    if  (sscanf( argv[2], "%f", &lon ) != 1)  {
        fprintf( stderr, "cannot read lon\n" );
        return 1;
    } /*endif*/

    get_geo( &lat, &lon, &regid, regname );
    printf( "%d %s\n", regid, regname );

} /* end of main */
