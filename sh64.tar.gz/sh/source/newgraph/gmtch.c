
/* file gmtch.c
 *      =======
 *
 * version 1, 7-Jul-2007
 *
 * GMT channel for graphics output module
 * K. Stammler, 7-Jul-2007
 */


#include <stdio.h>
#include <string.h>
#include BASECNST
#include BC_SYSBASE
#include "graphbas.h"
#include "gmtusrdef.h"
#include "gmterrors.h"

/* global constants */
#define GMTC_MAXSTYLE 10
	/* maximum number of different line styles */
#define DEFAULTWIDTH 100.0
	/* default width of user coo */
#define DEFAULTHEIGHT 100.0
	/* default height of user coo */
#define DEFAULTPLOTW 25.9
#define DEFAULTPLOTH 19.5
	/* default plot size */
#define MAXDEFSTYLE 6
	/* number of default styles */

#define GMTFILENAME "GMT_TMP"
	/* PostScript file */


/* global variable */
static char gmtv_outputdir[BC_FILELTH+1];  /* output directory */
static char gmtv_inputdir[BC_FILELTH+1];   /* input directory */


/* global variables */
static BOOLEAN gmtv_isinit;   /* GMT is initialised */
static GMTOUT  gmtv_width;    /* width of display */
static GMTOUT  gmtv_height;   /* heigth of display */
static GMTOUT  gmtv_xoffset;  /* x-offset */
static GMTOUT  gmtv_yoffset;  /* y-offset */
static float   gmtv_trafo_xf; /* trafo x-factor */
static float   gmtv_trafo_yf; /* trafo y-factor */
static GMTOUT  gmtv_trafo_xo; /* x-offset */
static GMTOUT  gmtv_trafo_yo; /* y-offset */
static BOOLEAN gmtv_arrayswap=FALSE;      /* swap arrayplot coo's */
static int     gmtv_currstyle; /* currently used style */
static float   gmtv_csize[GMTC_MAXSTYLE];  /* character sizes (units of height) */
static float   gmtv_lwidth[GMTC_MAXSTYLE]; /* line widths */
static FILE    *gmtv_pf;       /* pointer to PostScript file */
static BOOLEAN gmtv_move=FALSE;/* moveto buffer is not empty */
static GBC_COO gmtv_move_x;    /* moveto x-coo */
static GBC_COO gmtv_move_y;    /* moveto y-coo */

static char    gmtv_currfile[BC_FILELTH+1];   /* name of active GMT file */

/* prototypes of local routines */
void gmth_trafo( GBC_COO ux, GBC_COO uy, GMTOUT *dx, GMTOUT *dy );
void gmth_create_hcname( char name[] );
void gmth_insertheader( FILE *gmt );
void gmth_closefile( FILE *gmt );
void gmth_changestyle( int style );

/*----------------------------------------------------------------------------*/



void gmt_init( int attribs, GMTOUT xlo, GMTOUT ylo, GMTOUT width, GMTOUT height,
	STATUS *status )

/* initialises PostScript channel
 *
 * parameters of routine
 * int        attribs;        input; attributes
 * GMTOUT     xlo, ylo;       input; offset of output
 * GMTOUT     width, height;  input; size of output
 * STATUS     *status;        output; return status
 */
{
	/* local variables */
	int      i;      /* counter */
	FILE     *fp;    /* file pointer */

	/* executable code */

	printf ("--> in gmt_init\n" );

	if  (attribs == 0)  {
		;                  /* just to access attrib once */
	} /*endif*/

	if  (*gmtv_currfile == '\0')  {
		if  (strlen(gmtv_currfile)+strlen(GMTFILENAME)+8 > BC_FILELTH)  {
			*status = GMTE_STROVFL;
			return;
		} /*endif*/
		/* search for existing files */
		i = 0;
		FOREVER  {
			sprintf( gmtv_currfile, "%s%s%05d.ps", gmtv_outputdir, GMTFILENAME, i );
			fp = fopen( gmtv_currfile, "r" );
			if  (fp == NULL)  break;
			fclose( fp );
			i++;
		} /*endfor*/
	} /*endif*/

	if  ((width <= 0.0) || (height <= 0.0))  {
		*status = GMTE_ILPAR;
		return;
	} /*endif*/

	if  (gmtv_isinit)  gmt_exit();

	gmtv_xoffset = xlo;
	gmtv_yoffset = ylo;
	gmtv_width = width;
	gmtv_height = height;

	gmtv_currstyle = 0;
	for  (i=0; i<GMTC_MAXSTYLE; i++)
		if  (gmtv_csize[i] == 0.0)
			gmtv_csize[i] = 40.0;
	for  (i=0; i<GMTC_MAXSTYLE; i++)
		if  (gmtv_lwidth[i] == 0.0)
			gmtv_lwidth[i] = 0.4;

	/* open GMT file */
	gmtv_pf = sy_fopen( gmtv_currfile, "w" );
	if  (gmtv_pf == NULL)  {
		*status = GMTE_FOPNWR;
		return;
	} /*endif*/
	gmtv_isinit = TRUE;
	gmtv_move = FALSE;

	gmth_insertheader( gmtv_pf );
	gmt_setcoo( 0., 0., DEFAULTWIDTH, DEFAULTHEIGHT, status );

} /* end of gmt_init */



/*----------------------------------------------------------------------------*/



void gmt_exit( void )

/* exits GMT channel
 *
 * no parameters
 */
{
	/* executable code */

	printf ("--> in gmt_exit\n" );
	if  (!gmtv_isinit)  return;
	fclose( gmtv_pf );
	sy_fdelete( gmtv_currfile );
	gmtv_isinit = FALSE;

} /* end of ps_exit */



/*----------------------------------------------------------------------------*/



void gmt_resize( GMTOUT xlo, GMTOUT ylo, GMTOUT width, GMTOUT height,
	STATUS *status )

/* resizes output of GMT
 *
 * parameters of routine
 * GMTOUT     xlo, ylo;       input; offset of output
 * GMTOUT     width, height;  input; size of output
 * STATUS     *status;        output; return status
 */
{
	/* executable code */

	if  ((width <= 0.0) || (height <= 0.0))  {
		*status = GMTE_ILPAR;
		return;
	} /*endif*/

	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, status);

	gmtv_xoffset = xlo;
	gmtv_yoffset = ylo;
	gmtv_width = width;
	gmtv_height = height;

} /* end of gmt_resize */



/*----------------------------------------------------------------------------*/



void gmt_erase( void )

/* clears GMT output channel
 *
 * no parameters
 */
{
	/* local variables */
	int      dmy=0;

	/* executable code */

	printf ("--> in gmt_erase\n" );
	if  (gmtv_isinit)  {
		fseek( gmtv_pf, 0L, 0 );
		gmth_insertheader( gmtv_pf );
		gmtv_currstyle = 0;
	} else {
		gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, &dmy );
	} /*endif*/
	gmtv_move = FALSE;

} /* end of gmt_erase */



/*----------------------------------------------------------------------------*/



void gmt_setcoo( GBC_COO x, GBC_COO y, GBC_COO w, GBC_COO h, STATUS *status )

/* sets user coordinates
 *
 * parameters of routine
 * GBC_COO    x, y;     input; offset
 * GBC_COO    w, h;     input; size
 * STATUS     *status;  output; return status
 */
{
	/* executable code */

	if  ((w <= 0.0) || (h <= 0.0))  {
		*status = GMTE_ILPAR;
		return;
	} /*endif*/

	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, status);

	gmtv_trafo_xf = gmtv_width / w;
	gmtv_trafo_yf = gmtv_height / h;
	gmtv_trafo_xo = gmtv_xoffset - x*gmtv_trafo_xf;
	gmtv_trafo_yo = gmtv_yoffset - y*gmtv_trafo_yf;

} /* end of gmt_setcoo */



/*----------------------------------------------------------------------------*/



void gmt_moveto( GBC_COO x, GBC_COO y )

/* moves to position (x,y) in user coordinates, disabled
 *
 * parameters of routine
 * GBC_COO    x, y;    input; position
 */
{
	/* local variables */
	STATUS   dmy=0;    /* scratch */

	/* executable code */

#ifdef XXX
	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, &dmy );

	gmtv_move_x = x;
	gmtv_move_y = y;
	gmtv_move = TRUE;
#endif

} /* end of gmt_moveto */



/*----------------------------------------------------------------------------*/



void gmt_drawto( int style, GBC_COO x, GBC_COO y )

/* draws to position (x,y) in user coordinates, disabled
 *
 * parameters of routine
 * int        style;   input; style parameter
 * GBC_COO    x, y;    input; position
 */
{
	/* local variables */
	static int linecnt=0; /* counter of lineto commands */
	GMTOUT   dx, dy;      /* device coordinates */
	STATUS   dmy=0;       /* scratch */

	/* executable code */

#ifdef XXX
	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, &dmy );

	if  ((style < 0) || (style >= GMTC_MAXSTYLE))  style = 0;
	if  (style != gmtv_currstyle)
		gmth_changestyle( style );

	if  (gmtv_move)  {
		gmth_trafo( gmtv_move_x, gmtv_move_y, &dx, &dy );
		fprintf( gmtv_pf, "%d %d M\n", Nint(dx), Nint(dy) );
		gmtv_move = FALSE;
		linecnt = 0;
	} /*endif*/

	gmth_trafo( x, y, &dx, &dy );
	fprintf( gmtv_pf, "%d %d L\n", Nint(dx), Nint(dy) );
#endif

} /* end of gmt_drawto */


/*----------------------------------------------------------------------------*/



void gmt_arrayplot( int style, long cnt, int red, GBC_COO xoff,
	GBC_COO xinc, GBC_COO yoff, GBC_COO yarr[], float yzoom, STATUS *status )

/* plots array of data points
 *
 * parameters of routine
 * int        style;       input; style parameter
 * long       cnt;         input; number of data samples in yarr
 * int        red;         input; reduction factor
 * GBC_COO    xoff;        input; x offset
 * GBC_COO    xinc;        input; x increment
 * GBC_COO    yoff;        input; y offset
 * GBC_COO    yarr[];      input; data array
 * float      yzoom;       input; amplitude zoom factor
 * STATUS     *status;     output; return status
 */
{
	/* local variables */
	long     i;          /* sample counter */
	GBC_COO  cx, cy;     /* current user coordinates */
	GMTOUT   dx, dy;     /* current GMT coordinates */
	long     lcnt;       /* lineto counter */

	/* executable code */

	printf ("--> in gmt_arrayplot\n" );
	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, status);

	if  (style != gmtv_currstyle)
		gmth_changestyle( style );

	fprintf( gmtv_pf, "newpath\n" );

	lcnt = 0;
	if  (gmtv_arrayswap)  {
		cx = yoff + (*yarr)*yzoom;
		cy = xoff;
		gmth_trafo( cx, cy, &dx, &dy );
		fprintf( gmtv_pf, "%d %d M\n", Nint(dx), Nint(dy) );
		for  (i=red; i<cnt; i += red)  {
			cx = yoff + yarr[i]*yzoom;
			cy = xoff + xinc*(float)i;
			gmth_trafo( cx, cy, &dx, &dy );
			fprintf( gmtv_pf, "%d %d L\n", Nint(dx), Nint(dy) );
		} /*endfor*/
	} else {
		cx = xoff;
		cy = yoff + (*yarr)*yzoom;
		gmth_trafo( cx, cy, &dx, &dy );
		fprintf( gmtv_pf, "%d %d M\n", Nint(dx), Nint(dy) );
		for  (i=red; i<cnt; i += red)  {
			cx = xoff + xinc*(float)i;
			cy = yoff + yarr[i]*yzoom;
			gmth_trafo( cx, cy, &dx, &dy );
			fprintf( gmtv_pf, "%d %d L\n", Nint(dx), Nint(dy) );
		} /*endfor*/
	} /*endif*/

	fprintf( gmtv_pf, "stroke\n" );

	gmtv_move = FALSE;

} /* end of gmt_arrayplot */



/*----------------------------------------------------------------------------*/



void gmt_text( int style, GBC_COO x, GBC_COO y, char text[] )

/* prints text at position (x,y), disabled
 *
 * parameters of routine
 * int        style;     input; style parameter (size)
 * GBC_COO    x, y;      input; text position (user coordinates)
 * char       text[];    input; text to be printed
 */
{
	/* local variables */
	GMTOUT    dx, dy;  /* device coordinates */
	/* int      slen; */    /* length of string */
	/* float    size; */    /* size of output */
	STATUS   dmy;      /* scratch */

	/* executable code */

#ifdef XXX
	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, &dmy );

	if  (style < 0)  style = 0;
	if  (style >= GMTC_MAXSTYLE)  style = GMTC_MAXSTYLE-1;
	gmth_trafo( x, y, &dx, &dy );
	/* slen = (int)strlen( text ); */
	/* size = psv_csize[style] * psv_height; */
	if  (style != psv_currstyle)
		gmth_changestyle( style );
	fprintf( gmtv_pf, "%d %d M\n(%s)\ndrawstr\n", Nint(dx), Nint(dy), text );
#endif

} /* end of gmt_text */



/*----------------------------------------------------------------------------*/



void gmt_setstyle( int style, char item[], char value[], STATUS *status )

/* sets style parameter number "style"
 *
 * parameters of routine
 * int        style;     input; number of style
 * char       item[];    input; name of style attribute
 * char       value[];   input; new value of style attribute (as string expr.)
 * STATUS     *status;   output; return status
 */
{
	/* local variables */
	float    num;      /* scratch */
	float    r, g, b;  /* colours */

	/* executable code */

	if  ((style < 0) || (style >= GMTC_MAXSTYLE))  {
		*status = GMTE_ILSTYLE;
		return;
	} /*endif*/

	/* if  (!psv_isinit)  ps_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, status); */

	if  (strcmp(item,"CHARSIZE") == 0  ||  strcmp(item,"CHARHEIGHT") == 0)  {
		if  (sscanf(value,"%f",&num) != 1)  {
			*status = GMTE_ILVALUE;
			return;
		} /*endif*/
		gmtv_csize[style] = num*3000.0;
	} else if  (strcmp(item,"WRMODE") == 0)  {
	} else if  (strcmp(item,"LINESTYLE") == 0)  {
		/* not yet implemented */
	} else if  (strcmp(item,"COLOR") == 0)  {
		if  (sscanf(value,"%f,%f,%f",&r,&g,&b) != 3)  {
			*status = GMTE_ILVALUE;
			return;
		} /*endif*/
		/* not yet implemented */
	} else if  (strcmp(item,"CHARROT") == 0)  {
	} else if  (strcmp(item,"FONT") == 0)  {
	} else if  (strcmp(item,"LINEWIDTH") == 0)  {
		if  (sscanf(value,"%f",&num) != 1)  {
			*status = GMTE_ILVALUE;
			return;
		} /*endif*/
		gmtv_lwidth[style] = num*1.8;
	} else if  (strcmp(item,"LINEPATTERN") == 0)  {
	} else if  (strcmp(item,"CHARSIZE_ATARI") == 0)  {
	} else if  (strcmp(item,"TEXTEFFECTS") == 0)  {
	} else {
		*status = GMTE_UKITEM;
		return;
	} /*endif*/

} /* end of gmt_setstyle */



/*----------------------------------------------------------------------------*/



void gmt_set_outputdir( char dir[], STATUS *status )

/* sets scratch directory
 *
 * parameters of routine
 * char      dir[];     input; new directory name of scratch path
 * STATUS    *status;   output; return status
 */
{
	/* executable code */

	if  (strlen(dir) > BC_FILELTH)  {
		*status = GMTE_STROVFL;
		return;
	} /*endif*/
	strcpy( gmtv_outputdir, dir );

} /* end of gmt_set_outputdir */



/*----------------------------------------------------------------------------*/



void gmt_set_inputdir( char dir[], STATUS *status )

/* sets scratch directory
 *
 * parameters of routine
 * char      dir[];     input; new directory name
 * STATUS    *status;   output; return status
 */
{
	/* executable code */

	if  (strlen(dir) > BC_FILELTH)  {
		*status = GMTE_STROVFL;
		return;
	} /*endif*/
	strcpy( gmtv_inputdir, dir );

} /* end of gmt_set_inputdir */



/*----------------------------------------------------------------------------*/



void gmt_prepare( STATUS *status )

/* prepares hardcopy
 *
 * parameters of routine
 * STATUS     *status;    output; return status
 */
{
	/* local variables */

	/* executable code */

	printf ("--> in gmt_prepare\n" );
	gmt_erase();
	if  (Severe(status))  return;  /* just to use status */

} /* end of gmt_prepare */



/*----------------------------------------------------------------------------*/



void gmt_cleanup( char outf[], STATUS *status )

/* finishes GMT output
 *
 * parameters of routine
 * char       outf[];     output; output filename
 * STATUS     *status;    output; return status
 */
{
	/* local variables */
	char     hcname[BC_LINELTH+1];    /* name of hardcopy file */
	char     str[BC_LINELTH+1];       /* scratch string */
	/* char     cmd[BC_LINELTH+1]; */      /* command string */

	/* executable code */

	printf ("--> in gmt_cleanup\n" );
	if  (!gmtv_isinit)  gmt_init( 0, 0.0, 0.0, DEFAULTPLOTW, DEFAULTPLOTH, status);

	/* close PostScript file */
	gmth_closefile( gmtv_pf );

	/* create hardcopy name */
	gmth_create_hcname( hcname );

	strcpy( str, gmtv_outputdir );
	strcat( str, hcname );
	sy_fdelete( str );
	sy_frename( gmtv_currfile, str );
	if  (outf != NULL)  strcpy( outf, str );

	/* open GMT file */
	gmtv_pf = sy_fopen( gmtv_currfile, "w" );
	if  (gmtv_pf == NULL)  {
		*status = GMTE_FOPNWR;
		return;
	} /*endif*/
	gmth_insertheader( gmtv_pf );
	gmtv_currstyle = 0;    /* reset style block number */

} /* end of gmt_cleanup */



/*----------------------------------------------------------------------------*/



void gmt_setpar( char item[], char value[], STATUS *status )

/* sets hardcopy parameters
 *
 * parameters of routine
 * char       item[];     input; item to be set
 * char       value[];    input; new value of item
 * STATUS     *status;    output; return status
 */
{
	/* executable code */

#ifdef XXX
	if  (strlen(value) > BC_LINELTH)  {
		*status = GMTE_STROVFL;
		return;
	} /*endif*/

	if  (strcmp(item,"PRINT_CMD") == 0)  {
		/* strcpy( psv_printfmt, value ) */;
	} else if  (strcmp(item,"PSHEADER") == 0)  {
		if  (strlen(value) < BC_FILELTH)
			strcpy( psv_headerfile, value );
	} else {
		*status = PSE_UKHCITEM;
		return;
	} /*endif*/
#endif

} /* end of gmt_setpar */



/*----------------------------------------------------------------------------*/



void gmt_arrayswap( BOOLEAN on_off )

/* switches array-swap on ot off
 *
 * parameter of routine
 * BOOLEAN   on_off;     TRUE=on, FALSE=off
 */
{
	/* executable code */

	gmtv_arrayswap = on_off;

} /* end of gmt_arrayswap */



/*----------------------------------------------------------------------------*/
/*                            local routines                                  */
/*----------------------------------------------------------------------------*/



void gmth_trafo( GBC_COO ux, GBC_COO uy, GMTOUT *dx, GMTOUT *dy )

/* transforms user coordinates (ux,uy) to device coordinates (dx,dy)
 *
 * parameters of routine
 * GBC_COO    ux, uy;     input; user coordinates
 * GMTOUT     dx, dy;     output; device coordinates
 */
{
	/* executable code */

	*dx = ux * gmtv_trafo_xf + gmtv_trafo_xo;
	*dy = uy * gmtv_trafo_yf + gmtv_trafo_yo;

} /* end of gmth_trafo */



/*----------------------------------------------------------------------------*/



void gmth_create_hcname( char name[] )

/* creates hardcopy filename
 *
 * parameters of routine
 * char       name[];      output; filename created
 */
{
	/* local variables */
	static int   hc_count=0;   /* hardcopy counter */

	/* executable code */

	strcpy( name, "HC" );
	sprintf( name+2, "%03d", ++hc_count );
	strcat( name, ".gmt" );

} /* end of gmth_create_filename */



/*----------------------------------------------------------------------------*/


void gmth_insertheader( FILE *gmt )

/* inserts header to GMT file
 *
 * parameter of routine
 * FILE      *gmt;     input; PostScript file to insert header
 */
{
	/* local variables */
	FILE     *hf;                     /* header file */
	char     line[BC_LONGSTRLTH+1];   /* current line */
	char     timestr[BC_LINELTH+1];   /* time string */

	/* executable code */

	fprintf( gmt, "# some comment\n" );

} /* end of gmth_insertheader */



/*----------------------------------------------------------------------------*/


void gmth_closefile( FILE *gmt )

/* closes hardcopy file
 *
 * parameter of routine
 * FILE      *gmt;      input; pointer to hardcopy file
 */
{

	/* executable code */

	fclose( gmt );

} /* end of gmth_closepsf */



/*----------------------------------------------------------------------------*/



void gmth_changestyle( int style )

/* changes the current style, disabled
 *
 * parameters of routine
 * int        style;      input; new style number
 */
{
	/* executable code */

	if  (style < 0)  style = 0;
	if  (style >= GMTC_MAXSTYLE)  style = 0;
	gmtv_currstyle = style;

} /* end of gmth_changestyle */



/*----------------------------------------------------------------------------*/
