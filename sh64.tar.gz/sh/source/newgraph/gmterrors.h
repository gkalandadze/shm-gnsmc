
/* file gmterrors.h
 *      ===========
 *
 * version 1, 1-Jul-2007
 *
 * status code definitions of module gmtch.c
 * K. Stammler, 1-Jul-2007
 */


#define GMTE_NOERROR    0
#define GMTE_OFFSET     9100
#define GMTE_ILPAR      (GMTE_OFFSET+1)    /* illegal parameter */
#define GMTE_ILSTYLE    (GMTE_OFFSET+2)    /* illegal style number */
#define GMTE_UKITEM     (GMTE_OFFSET+3)    /* unknown style attribute */
#define GMTE_ILVALUE    (GMTE_OFFSET+4)    /* illegal value of attribute */
#define GMTE_JOBSUBMIT  (GMTE_OFFSET+5)    /* error submitting job */
#define GMTE_FOPNWR     (GMTE_OFFSET+6)    /* error opening output file */
#define GMTE_UKHCITEM   (GMTE_OFFSET+7)    /* unknown HC item */
#define GMTE_STROVFL    (GMTE_OFFSET+8)    /* string overflow */
