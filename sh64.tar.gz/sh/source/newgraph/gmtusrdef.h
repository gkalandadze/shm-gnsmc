
/* file gmtusrdef.h
 *      ===========
 *
 * version 1, 7-Jul-2007
 *
 * interface of GMT channel to graphics module
 * K. Stammler, 7-Jul-2007
 */

#ifndef __GMTUSRDEF
#define __GMTUSRDEF


typedef float GMTOUT;




/*----------------------------------------------------------------------------*/


void gmt_init( int attribs, GMTOUT xlo, GMTOUT ylo, GMTOUT width, GMTOUT height,
   STATUS *status );

/* initialises GMT channel
 *
 * parameters of routine
 * int        attribs;        input; attributes
 * GMTOUT     xlo, ylo;       input; offset of output
 * GMTOUT     width, height;  input; size of output
 * STATUS     *status;        output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_exit( void );

/* exits GMT channel
 *
 * no parameters
 */


/*----------------------------------------------------------------------------*/


#define gmt_finish gmt_exit


/*----------------------------------------------------------------------------*/


void gmt_resize( GMTOUT xlo, GMTOUT ylo, GMTOUT width, GMTOUT height,
   STATUS *status );

/* resizes output of PostScript
 *
 * parameters of routine
 * GMTOUT     xlo, ylo;       input; offset of output
 * GMTOUT     width, height;  input; size of output
 * STATUS     *status;        output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_erase( void );

/* clears GMT output channel
 *
 * no parameters
 */


/*----------------------------------------------------------------------------*/


void gmt_prepare( STATUS *status );

/* prepares hardcopy
 *
 * parameters of routine
 * STATUS     *status;    output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_cleanup( char outf[], STATUS *status );

/* finishes hardcopy
 *
 * parameters of routine
 * char       outf[];     output; output filename
 * STATUS     *status;    output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_setcoo( GBC_COO x, GBC_COO y, GBC_COO w, GBC_COO h, STATUS *status );

/* sets user coordinates
 *
 * parameters of routine
 * GBC_COO    x, y;     input; offset
 * GBC_COO    w, h;     input; size
 * STATUS     *status;  output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_moveto( GBC_COO x, GBC_COO y );

/* moves to position (x,y) in user coordinates
 *
 * parameters of routine
 * GBC_COO    x, y;    input; position
 */


/*----------------------------------------------------------------------------*/


void gmt_drawto( int style, GBC_COO x, GBC_COO y );

/* draws to position (x,y) in user coordinates
 *
 * parameters of routine
 * int        style;   input; style parameter
 * GBC_COO    x, y;    input; position
 */


/*----------------------------------------------------------------------------*/


void gmt_arrayplot( int style, long cnt, int red, GBC_COO xoff,
   GBC_COO xinc, GBC_COO yoff, GBC_COO yarr[], float yzoom, STATUS *status );

/* plots array of data points
 *
 * parameters of routine
 * int        style;       input; style parameter
 * long       cnt;         input; number of data samples in yarr
 * int        red;         input; reduction factor
 * GBC_COO    xoff;        input; x offset
 * GBC_COO    xinc;        input; x increment
 * GBC_COO    yoff;        input; y offset
 * GBC_COO    yarr[];      input; data array
 * float      yzoom;       input; amplitude zoom factor
 * STATUS     *status;     output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_text( int style, GBC_COO x, GBC_COO y, char text[] );

/* prints text at position (x,y)
 *
 * parameters of routine
 * int        style;     input; style parameter (size)
 * GBC_COO    x, y;      input; text position (user coordinates)
 * char       text[];    input; text to be printed
 */


/*----------------------------------------------------------------------------*/


void gmt_setstyle( int style, char item[], char value[], STATUS *status );

/* sets style parameter number "style"
 *
 * parameters of routine
 * int        style;     input; number of style
 * char       item[];    input; name of style attribute
 * char       value[];   input; new value of style attribute (as string expr.)
 * STATUS     *status;   output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_set_outputdir( char dir[], STATUS *status );

/* sets scratch directory
 *
 * parameters of routine
 * char      dir[];     input; new directory name of scratch path
 * STATUS    *status;   output; return status
 */


/*----------------------------------------------------------------------------*/


void gmt_set_inputdir( char dir[], STATUS *status );

/* sets input directory
 *
 * parameters of routine
 * char      dir[];     input; new directory name
 * STATUS    *status;   output; return status
 */


/*----------------------------------------------------------------------------*/


#define gmt_charsize(s,x,t)

/*----------------------------------------------------------------------------*/


#define gmt_linestyle(s,l,t)

#define gmt_linewidth(s,l,t)

/*----------------------------------------------------------------------------*/


#define gmt_color(s,r,g,b,t)

/*----------------------------------------------------------------------------*/


void gmt_setpar( char item[], char value[], STATUS *status );

/* sets hardcopy parameters
 *
 * parameters of routine
 * char       item[];     input; item to be set
 * char       value[];    input; new value of item
 * STATUS     *status;    output; return status
 */


/*----------------------------------------------------------------------------*/


#define gmt_aspectratio() 1.0

/*----------------------------------------------------------------------------*/


void gmt_arrayswap( BOOLEAN on_off );

/* switches array-swap on or off
 *
 * parameter of routine
 * BOOLEAN   on_off;     TRUE=on, FALSE=off
 */


/*----------------------------------------------------------------------------*/



#endif /* __GMTUSRDEF */

