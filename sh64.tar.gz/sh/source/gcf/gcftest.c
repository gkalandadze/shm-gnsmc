
/* file gcftest.c
 *      =========
 *
 * version 1, 20-Oct-2003
 *
 * GCF test routine
 *
 * K. Stammler, 20-Oct-2003
 */

#include <stdio.h>
#include <string.h>
#include "basecnst.h"
#include "sysbase.h"
#include "tcusrdef.h"
#include "gcflib.h"



int main( int argc, char *argv[] )
{
	/* local variables */
	char     stream_str[cBcLineLth+1];
	char     start[cBcLineLth+1];
	char     act_start[cBcLineLth+1];
	char     gfdfile[cBcLineLth+1];
	long     *ldat;
	long     smplth;
	float    dt;
	float    calib;
	GcfFileDescrT fdescr;
	TSyStatus status;

	/* executable code */

	status = cBcNoError;

	strcpy( stream_str, "ssht-hh-z" );
	strcpy( start, "18-Oct-2003_7:56:00.0" );
	strcpy( gfdfile, "/home/klaus/gcftest/gcf/gfdfile.gfd" );


	/* test GcfSearchPosition */

	printf( "\n" );
	GcfSearchPosition( 0, gfdfile, stream_str, start, act_start, &status );
	printf( "\n" );

	printf( "act_start %s\n", act_start );
	printf( "status %d\n", status );
} /* end of main */
