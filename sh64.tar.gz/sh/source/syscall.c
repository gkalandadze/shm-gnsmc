
/* File SYSCALL.C
 *      =========
 *
 * version 37, 7-Dec-2006
 *
 * calls of system dependent routines
 * this file contains all available implementations
 * K. Stammler, 27-FEB-1990
 */


/*
 *
 *  SeismicHandler, seismic analysis software
 *  Copyright (C) 1992,  Klaus Stammler, Federal Institute for Geosciences
 *                                       and Natural Resources (BGR), Germany
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


#include "basecnst.h"


/* SUN version 1, 18-JUN-91
 * originally implemented in Dublin, DIAS
 * K. Stammler, 27-FEB-1990
 */

#include <stdio.h>
#include <string.h>
#ifdef BC_STDLIB_EX
#include <stdlib.h>
#endif
#include <sys/types.h>
#include <sys/times.h>
#include "sysbase.h"
#include "syerrors.h"
/* #include "shvars.h" */

#define MAXFFCMDLTH 300

/*------------------------------------------------------------------------*/



void *sy_allocmem( long cnt, int size, STATUS *status )

/* allocates memory ("cnt" objects of size "size)
 *
 * parameters of routine
 * long     cnt;            input; number of objects
 * int      size;           input; size of each object
 * STATUS   *status;        output; return status
 */
{
	/* local variables */
	void     *ptr;     /* pointer to allocated memory */

	/* executable code */

	ptr = (void *)malloc( cnt*size );
	if  (ptr == NULL)  {
		printf( "--> couldn't allocate %d * %d bytes\n", cnt, size );
		*status = SYE_MEMOVFL;
	} /*endif*/
	return ptr;

} /* end of sy_allocmem */



/*------------------------------------------------------------------------*/



FILE *sy_fopen( char file[], char access[] )

/* opens file.  Backslashes "\" in the filename are converted to slashes "/"
 *
 * parameters of routine
 * char       file[];        input; filename of file to be opened
 * char       access[];      input; access string
 *                           returns pointer to file or NULL
 */
{
	/* local variables */
	char     locname[BC_FILELTH+1];     /* local filename */
	char     *cp;                       /* character pointer */

	/* executable code */

	if  (strlen(file) > BC_FILELTH)  {
		printf( "--> sy_fopen: filename too long: not modified\n" );
		return fo_fopen( file, access );
	} /*endif*/

	cp = locname;
	while  (*file != '\0')  {
		if  (*file == '\\')  {
			*cp++ = '/';
			file++;
		} else {
			*cp++ = *file++;
		} /*endif*/
	} /*endwhile*/
	*cp = '\0';

	return fo_fopen( locname, access );

} /* end of sy_fopen */



/*------------------------------------------------------------------------*/



void sy_findfile( int request, char wild[], char filename[] )

/* looks for files matching wild card string "wild". Returns filename of
 * file found (with/without directory and/or extension, depending on "request") or
 * "\0" if not found.
 *
 * parameters of routine
 * int      request;        input; what elements (name,dir,ext)
 * char     *wild;          input; wild card string
 * char     *filename;      output; next file found
 */
{
	/* local variables */
	static char   currwild[BC_FILELTH+1]="";  /* current wild card string */
	static char   dirfile[BC_FILELTH+1]="";   /* output filename */
	static char   errfile[BC_FILELTH+1]="";   /* error output filename */
	static FILE   *df=NULL;                     /* directory file */
	char          cmd[MAXFFCMDLTH+1];      /* command string */
	int           filpos;                  /* position of file name */
	int           extpos;                  /* position of extension */
	char          *c;                      /* moving pointer */
	static int    callcnt=0;               /* call counter */

	/* executable code */

	if  (*dirfile == '\0')  {
		c = getenv( "SH_SCRATCH" );
		if  (c == NULL)  c = getenv( "HOME" );
		if  (c != NULL && strlen(c) < BC_FILELTH-11)  {
			strcpy( dirfile, c );
			filpos = (int)strlen( dirfile ) - 1;
			if  (dirfile[filpos] != '/')
				strcat( dirfile, "/" );
		} else {
			*dirfile = '\0';
		} /*endif*/
		sprintf( dirfile+strlen(dirfile), "%03d", ++callcnt );
		strcpy( errfile, dirfile );
		strcat( dirfile, "DIR.TMP" );
		strcat( errfile, "ERR.TMP" );
	} /*endif*/

	if  (*wild == '\0')  {
		*currwild = '\0';
		if  (df != NULL)  fclose( df );
		df = NULL;
		return;
	} /*endif*/

	if  (strcmp(currwild,wild) != 0)  {  /* new wild card string */
		if  (df != NULL)  fclose( df );
		strcpy( currwild, wild );
		strcpy( cmd, "ls -1 " );
		strcat( cmd, wild );
		strcat( cmd, " >" );
		strcat( cmd, dirfile );
		strcat( cmd, " 2>" );
		strcat( cmd, errfile );
		system( cmd );
		df = fopen( dirfile, "r" );
		if  (df == NULL)  {
			*currwild = '\0';
			*filename = '\0';
			return;
		} /*endif*/
	} /*endif*/

	if  (fgets(filename,BC_FILELTH,df) == NULL) {
		if  (df != NULL)  fclose( df );
		df = NULL;
		*currwild = '\0';
		*filename = '\0';
		return;
	} /*endif*/

	filpos = strlen( filename ) - 1;
	if  (filename[filpos] == '\n')  filename[filpos] = '\0';

	if  (request == (SYC_FF_NAME|SYC_FF_EXT|SYC_FF_DIR))  return;

	filpos = extpos = 0;
	c = filename;
	while  (*c != '\0')  {
		if  (*c == '.')  {
			extpos = c-filename;
		} else if (*c == '/')  {
			filpos = c-filename;
		} /*endif*/
		c++;
	} /*endwhile*/

	if  (!(SYC_FF_EXT & request)  &&  extpos > 0)
		filename[extpos] = '\0';

	if  (!(SYC_FF_DIR & request)  &&  filpos > 0)
		strcpy( filename, filename+filpos+1 );

} /* end of sy_findfile */



/*------------------------------------------------------------------------*/



double sy_random( double ampl )

/* creates random number with absolute value less than (or equal to)
 * "amp"
 *
 * parameters of routine
 * double      ampl;      input; max. amplitude; if zero, a new random
 *                               series is started
 */
{
	/* local constants */
#	define MAXRAND 32767.0

	/* local variables */
	int      rdm;         /* integer random result */

	/* executable code */

	return (drand48()*ampl);

} /* end of sy_random */



/*------------------------------------------------------------------------*/



void sy_randomstr( int lth, char str[] )

/* creates random string of length "lth"
 *
 * parameters of routine
 * int        lth;      input; length of output string
 * char       str[];    output; random string
 */
{
	/* local variables */
	time_t  timev;      /* current time */
#	ifndef cBc_OS_AIX
	struct tms ts;
#	endif
	char     minstr[6]; /* minimum length string */
	int      i;         /* counter */

	/* executable code */

	if  (lth < 3)  {
		*str = '\0';
		return;
	} /*endif*/
	*str++ = '_';
	lth -= 2;

#	ifndef cBc_OS_AIX
	times(&ts);
	timev = ts.tms_utime;
	timev %= 10000;
#	else
	timev = 4786;  /* o.k., not very sophisticated ... */
#	endif
	sprintf( minstr, "%04d", timev );
	if  (lth < 4)  {
		for  (i=0;i<lth;i++)
			str[i] = minstr[i];
	} else {
		strcpy( str, minstr );
		for  (i=4; i<lth; i++)
			str[i] = '0';
	} /*endif*/
	str[lth] = '_';
	str[lth+1] = '\0';

} /* end of sy_randomstr */



/*------------------------------------------------------------------------*/



void sy_localinf( char item[], char value[], STATUS *status )

/* returns local info in "value"
 *
 * parameters of routine
 * char       item[];     input; info item
 * char       value[];    output; return value
 * STATUS     *status;    output; return status
 */
{
	/* local variables */
	char     *eptr;

	/* executable code */

	if  (strncmp(item,"GETENV:",7) == 0)  {
		eptr = getenv( item+7 );
		if  (eptr == NULL)  {
			*value = '\0';
			return;
		} /*endif*/
		if  (strlen(eptr) > BC_LINELTH)  {
			*status = SYE_STROVFL;
			*value = '\0';
			return;
		} /*endif*/
		strcpy( value, eptr );
	} else {
		*status = SYE_LOCALINF;
	} /*endif*/

} /* end of sy_localinf */



/*----------------------------------------------------------------------------*/



void sy_byteorder( char bo[5] )

/* parameters of routine
 *
 * int        bo[5]; output; byte order in longword, like 1,2,3,4
 */
{
	/* local variables */
	char     fname[cBcFileLth+1];     /* name of scratch output file */
	char     *env;                    /* pointer to environment value */
	char     rstr[cBcShortStrLth+1];  /* random string */
	FILE     *fp;                     /* pointer to output file */
	long     lw;                      /* longword */
	int      i;                       /* counter */

	/* executable code */

	/* find output file */
	sy_randomstr( 4, rstr );
	env = (char *)getenv( "HOME" );
	if  (env == NULL)  {
		strcpy( fname, "/tmp" );
	} else {
		strcpy( fname, env );
	} /*endif*/
	strcat( fname, "/" );
	strcat( fname, "bo_" );
	strcat( fname, rstr );
	strcat( fname, ".000" );

	fp = sy_fopen( fname, "w" );
	if  (fp == NULL)  {
		strcpy( bo, "0000" );
		return;
	} /*endif*/

	lw = (0x31 << 24) + (0x32 << 16) + (0x33 << 8) + 0x34;
	fwrite( &lw, 4, 1, fp );

	sy_fclose( fp );

	fp = sy_fopen( fname, "r" );
	if  (fp == NULL)  {
		strcpy( bo, "0000" );
		return;
	} /*endif*/

	for  (i=0; i<4; i++)
		bo[i] = fgetc( fp );
	bo[5] = '\0';

	sy_fclose( fp );

	sy_fdelete( fname );

} /* sy_byteorder */



/*----------------------------------------------------------------------------*/
