#! /bin/bash

echo ""
echo "Self Extracting Installer for Seismic Handler"
echo ""

echo "Please read and execute all installation instructions for your"
echo "operating system as explained at the Seismic Handler project website:"
echo "http://www.seismic-handler.org/portal/wiki/Installation"
echo ""
read -p "Did you execute all neccessary steps (type 'yes')? " yes
[ "$yes" = "yes" ] || exit

which base64 > /dev/null 2>&1
[ $? -eq 0 ] || \
           (echo "'base64' tool for decoding not found, please install."; exit)

export TMPDIR=`mktemp -d /tmp/selfextract.XXXXXX`

echo "Extracting files to temporary directory ${TMPDIR}..."

ARCHIVE=`awk '/^__ARCHIVE_BELOW__/ {print NR + 1; exit 0; }' $0`

tail -n+$ARCHIVE $0 | base64 -di | tar xz -C $TMPDIR

CDIR=`pwd`
cd $TMPDIR

# parse options
while getopts "l:f:v" OPTION
do
     case $OPTION in
         l)
             LOCSAT=$OPTARG
             ;;
         f)
             FK=$OPTARG
             ;;
         v)
             VERBOSE=1
             ;;
     esac
done

[ "$LOCSAT" = "" ] || LOCSAT="--locsat=$LOCSAT"
[ "$FK" = "" ] || FK="--fk=$FK"
[ "$VERBOSE" = "" ] || VERBOSE="--debug"

python ./setup/setup.py $LOCSAT $FK $VERBOSE

result=$?

cd $CDIR
if [ $result -eq 0 ] ; then
    echo "Installation successful, removing temporary directory..."
    rm -rf $TMPDIR
    exit 0
else
    echo "Installation unsuccessful, keeping temporary directory..."
    echo ""
    echo "You can restart installation procedure by cd'ing into"
    echo $TMPDIR "and running ./setup/setup.py [--debug]"
    exit 1
fi

__ARCHIVE_BELOW__
