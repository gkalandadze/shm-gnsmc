#! /bin/bash
#
# file shsetup
#      =======
#
# This file must be 'source'd in a bash shell before running SH.
# Please edit the beginning of the file to match your environment.

#
#
# root path
# ---------
#
# root path for SH (this is where the directories 'source', 'util',
# 'help', etc ..., are)
#
shcroot=$HOME/bin/sh
userroot=$HOME/shfiles

#
#
# compiler switches
# -----------------
#
# If you have to recompile the sources set appropriate values to these
# environment variables.
# SH_COMPILER   :   The ANSI compiler (like gcc or acc, others I didn't check)
#                   The ordinary cc of Sun-Solaris-1 does NOT work.
# SH_CCOPTIONS  :   Options passed to the compiler.  Debugging (-g) is enabled
#                   by default.  Don't use '-DSH_SETUP_GRF' at other places
#                   than SZGRF observatory.  If you want to have compiled the
#                   AH-interface specify '-DSH_SETUP_AH'.  But then you
#                   need (a) to specify also '-lahio' on SH_LINKLIBS and (b)
#                   an appropriate AH-library (libahio.a) in $SH_LIB.  The
#                   one provided is working only on Sun Solaris-1 (SunOS 4.1.3).
# SH_TEXTEDIT   :   Call to (graphical) text editor, like 'gedit' in OpenLook
#                   or 'vuepad' in HP-UX.
# SH_LINKLIBS   :   Additional libraries linked to the executables.  '-lahio'
#                   is required if you have specified '-DSH_SETUP_AH' on
#                   SH_CCOPTIONS (see above).
# SH_MOTIFLIBS  :   extra libraries for OSF/Motif
# SH_LINKOPTIONS:   Additional library paths
# SH_RANLIB     :   ranlib-program for libraries.  Usually 'ranlib' on
#                   Sun-Solaris-1 and 'touch' (which means: do nothing) on
#                   Sun-Solaris-2.
#
# some example settings:
#
# (1) version for Solaris-2 with gcc compiler, with AH (tested at SZGRF)
#OS-sol2 export SH_COMPILER=gcc
#OS-sol2 export SH_CCOPTIONS='-g -DSH_SETUP_AH  -I/usr/dt/include -I/usr/openwin/share/include'
#OS-sol2 export SH_TEXTEDIT=gedit
#OS-sol2 export PSVIEW=evince
#OS-sol2 export SH_LINKLIBS='-lahio -lnsl'
#OS-sol2 export SH_MOTIFLIBS=''
#OS-sol2 export SH_LINKOPTIONS='-L/usr/dt/lib'
#OS-sol2 export SH_RANLIB=touch
#
# (2) version for Linux with gcc compiler (tested at SZGRF)
export SH_COMPILER=gcc
export SH_CCOPTIONS='-g -DSH_SETUP_LINUX -DSH_SETUP_AH -I/usr/X11R6/include'
export SH_TEXTEDIT=gedit
export PSVIEW=evince
export SH_LINKLIBS='-lahio'
#export SH_MOTIFLIBS='-lXp -lSM -lICE -lXpm -static'  # static version
export SH_MOTIFLIBS='-lICE -lSM -lXpm'               # dynamic version
export SH_LINKOPTIONS='-L/usr/X11R6/lib'
export SH_RANLIB=ranlib


# -----------------------------------------------------------------------------
#  Do not edit beyond this point (at least try to)
# -----------------------------------------------------------------------------


# paths
export SH_ROOT=$shcroot
export SH_USERROOT=$userroot
export SH_HELP=$shcroot/help/
export SH_COMMAND=$shcroot/command/
export SH_COMMAND2=$shcroot/command/bmp/
export SH_FILTER=$shcroot/filter/
export SH_GLOBALS=$shcroot/globals/
export SH_ERRORS=$shcroot/errors/
export SH_INPUTS=$shcroot/inputs/
export SH_UTIL=$shcroot/util/
export SH_PDE=$shcroot/inputs/pde/
export SH_SOURCE=$shcroot/source/
export SH_EXTPROG=$shcroot/util/
export SH_LIB=$shcroot/lib/
[ -d $SH_USERROOT ] || mkdir $SH_USERROOT
if [ ! -d $SH_USERROOT/shscratch ] ; then
   echo 'creating directory $SH_USERROOT/shscratch'
   mkdir $SH_USERROOT/shscratch
fi
if [ ! -d $SH_USERROOT/private ] ; then
   echo 'creating directory $SH_USERROOT/private'
   mkdir $SH_USERROOT/private
fi
export SH_SCRATCH=$SH_USERROOT/shscratch/
export SH_USERDIR=$SH_USERROOT/private/
export SH_PRIVATE=$SH_USERROOT/private/
alias SH="rlwrap $shcroot/shc_world"
alias SH_N=$shcroot/shc

#
# all following instructions are not needed for the command line version SH
# -------------------------------------------------------------------------
#
# for SHM
#
alias SHM='(export UIDPATH=$shcroot/source/motif/shm_world.uid; $shcroot/source/motif/shm_world)'
alias SHM_N='(export UIDPATH=$shcroot/source/motif/shm.uid; $shcroot/source/motif/shm)'
#
# for utility programs of SHM
#
export SH_LOCSAT=$HOME/lcs
export SH_LOCSAT_EXEC=$SH_UTIL/LocSAT
#
# for SEED software
#
export SEED_INPUTS=$SH_SOURCE/seed_io/inputs
export SEED_PROG=$SH_SOURCE/seed_io
alias sfdlist=$SEED_PROG/sfdlist.csh
alias sfdlist_l=$SEED_PROG/sfdlist_l.csh
alias sfd_extract_times=$SEED_PROG/sfd_extract_times
alias seed_tape=$SEED_PROG/seed_tape
alias seed_gaps=$SEED_PROG/seedgaps
