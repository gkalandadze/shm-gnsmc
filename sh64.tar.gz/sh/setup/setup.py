#! /usr/bin/env python

import os
import sys
import shutil

default_location = "/usr/local/sh"
downloads = {
    "locsat": "ftp://ftp.szgrf.bgr.de/pub/software/locsat-linux.tar.gz",
    "fk": "ftp://ftp.szgrf.bgr.de/pub/software/fk-linux.tar.gz"
}

def fetchinfo(**kwargs):
    """
    Fetch information about user etc.
    """
    dbg = kwargs["debug"]

    home = os.getenv("HOME")
    pwd = os.path.realpath(os.path.split(sys.argv[0])[0])
    tmp = os.getenv("TEMP")
    if not tmp:
        tmp = pwd

    uid = os.getuid()
    root = uid == 0
    if root:
        shcroot = default_location
    else:
        shcroot = os.path.join(home, "bin")

    del kwargs
    return locals()

def banner():
    print "="*70
    print "  Setup program for Seismic Handler (SH/SHM)"
    print "="*70
    print "\n This piece of software will try to setup the included source code.\n"

def download(target, pkg, dbg):
    print "Downloading %s..." % pkg

    verbose = "-q "
    if dbg:
        verbose = ""
        print downloads[pkg]

    if downloads[pkg].split(":")[0].lower() in ["http", "ftp"]:
        error = os.system("wget %s-P %s %s" % (verbose, target, downloads[pkg]))
    else:
        # try to copy file
        error = True
        try:
            shutil.copy(downloads[pkg], target)
            error = False
        except IOError:
            pass

    if error:
        abort("Cannot access %s. Exit here." % pkg)

def setup(**kwargs):
    """
    Setup Seismic Handler from source.
    """
    banner()
    dbg = kwargs["debug"]

    data = fetchinfo(debug=dbg)
    if dbg:
        print data

    if not data["root"]:
        res = query("You are not root (so maybe you haven't administrative rights).\n"
                    "Perform user installation [Yn]? ")
        if res.lower() == "n":
            abort()

    # override?
    data["shcroot"] = kwargs.get("target", False) or data["shcroot"]

    while 1:
        target = query("Installation directory [%s, q = exit]: " % data["shcroot"])
        if target.lower() == "q":
            abort()

        if not target:
            target = data["shcroot"]

        if not os.path.exists(target):
            try:
                os.mkdir(target)
            except Exception, e:
                if dbg:
                    print e

                print "Cannot create target directory: %s" % target
                continue

        break

    if dbg:
        print "Installation target: %s" % target

    copy(os.path.join(data["pwd"], ".."), os.path.join(target, "sh"), dbg)

    for pkg in ["locsat", "fk"]:
        downloads[pkg] = kwargs.get(pkg)
        download(target, pkg, dbg)

    exitcode = install(target, dbg)
    if exitcode == 99:
        abort("Installation aborted.")
    elif exitcode:
        abort("Installation errors occured. Please check output.")

    customize(target, dbg)

def customize(target, dbg):
    """
    Offers usage of new configuration files.

    Save user defined configuration files, if choosen.
    """

    flist = ["STATINF.DAT", "sensitivities.txt", "filter_lookup.txt"]

    print "\nSeismic Handler comes with updated station configuration files."
    a = raw_input("Do you want to use them (backup will be saved) [Yn]? ")

    if a == "n":
        print "\nPlease check the following files manually (sh/inputs):"
        for f in flist:
            print f, "vs.", f+".dist"
        return

    for f in flist:
        tname = os.path.join(target, "sh/inputs", f)
        if os.path.exists(tname):
            print "Backing up %s... (to %s)" % (f, f+".yours")
            os.system("cp %s %s" % (tname, tname+".yours"))
        os.system("cp %s %s" % (tname+".dist", tname))

def install(target, dbg):
    exitcode = \
         os.system(os.path.join(target, "sh/setup/SHM-install.csh %s" % target))

    return exitcode >> 8

def copy(src, trt, dbg=False):
    if dbg:
        os.system("cp -rvd %s %s" % (src, trt))
    else:
        os.system("cp -rd %s %s" % (src, trt))

    # in fact only necessary in root install mode
    os.chmod(trt, 0755)

def abort(text=None):
    if not text:
        text = "Installation aborted by user."

    quit(text)

def query(text):
    """
    Query user.
    """
    return raw_input(text)

if __name__ == "__main__":
    from sys import version_info
    if version_info < (2, 5):
        import warnings
        warnings.warn("Your installed python version is too old. This "
                      "software is tested on python 2.5 and higher only!")

    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("--debug", dest="debug", action="store_true",
                      help="Turn on debug option.", default=False)

    parser.add_option("--locsat", dest="locsat", action="store",
                      help="Overwrite locsat installation source.",
                      default=downloads["locsat"])

    parser.add_option("--fk", dest="fk", action="store",
                      help="Overwrite fk package installation source.",
                      default=downloads["fk"])

    parser.add_option("--target", dest="target", action="store",
                      help="Override default install target.",
                      default=None)

    (options, args) = parser.parse_args()

    setup(**vars(options))
