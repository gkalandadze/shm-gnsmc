#!/bin/bash

# Script for building a Seismic Handler release from subversion repository.
# Main tasks:
#   1. svn export into temporary directory
#   2. remove all unwanted files from export
#   3. build compressed tar file
#   4. create self-executing installation script
#

LANG=C
SRC=$1
[ "$SRC" == "" ] && SRC="trunk"
URI="https://www.seismic-handler.org/svn/SH_SHM/${SRC}/"

function setup {
    TMPDIR=`mktemp -d /tmp/release.XXXXXX`
    echo "0. Temp directory: $TMPDIR"
    #TMPDIR=/tmp/release.b26070/
}

function cleanup {
    rm -rf $TMPDIR
    echo "Done. Temp directory removed."
}

function exportsource {
    echo "1. Exporting source from subversion server..."
    svn --force --quiet export $URI $TMPDIR
    rev=`svn info $URI | awk -F": " '$1=="Last Changed Rev" {print $2}'`
}

function update {
    echo "2. Updating source tree..."

    delinput="shm-config.txt LocalStatinf.dat LocalSensitivities.dat \
              LocalFilterLookup.dat"

    for i in $delinput ; do rm -f $TMPDIR/inputs/$i ; done

    mv $TMPDIR/inputs/STATINF.DAT $TMPDIR/inputs/STATINF.DAT.dist
    mv $TMPDIR/inputs/sensitivities.txt $TMPDIR/inputs/sensitivities.txt.dist
    mv $TMPDIR/inputs/filter_lookup.txt $TMPDIR/inputs/filter_lookup.txt.dist
    mv $TMPDIR/inputs/chantrans.txt $TMPDIR/inputs/chantrans.txt.dist
    echo $rev > $TMPDIR/setup/revision
}

function compress {
    echo "3. Building tar archive..."
    cd $TMPDIR
    tar czf SHM.tar.gz *
    cd $OLDPWD
}

function joinarchive {
    echo "4. Creating self-extracting executable..."
    cat $TMPDIR/setup/decompress.sh > /tmp/SHM-install.sh
    base64 $TMPDIR/SHM.tar.gz >> /tmp/SHM-install.sh
    chmod 755 /tmp/SHM-install.sh
}

function main {
    setup
    exportsource
    update
    compress
    joinarchive
    cleanup
}

main
